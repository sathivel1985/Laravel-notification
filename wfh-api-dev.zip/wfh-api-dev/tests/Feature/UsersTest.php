<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use Illuminate\Support\Str;
class UsersTest extends TestCase
{
    /**
     * Admin can view user lists.
     *
     * @test
     */
    public function is_admin_can_get_user_lists()
    {
        $user = User::first();
        $authorize =$user->createToken('authToken');
        $header =  [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => "Bearer". $authorize->accessToken
        ];

        $response = $this->actingAs($user,'api')->getJson('api/users',$header);
        $response->assertJsonStructure([
            'data' => [
            ]
        ]);
    }

    /**
     * Use Login .
     *
     * @test
     */
    public function is_user_can_login()
    {
        $user = User::factory()->create();

        $authorize =$user->createToken('authToken');

        $header =  [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => "Bearer". $authorize->accessToken
        ];
        $responseObject = $this->actingAs($user,'api')->getJson('api/user/profile',$header);
        $responseArray = json_decode($responseObject->getContent(),true);

        $this->assertEquals($user->email, $responseArray['data']['email']);

    }

    /**
     * Use can have default role .
     *
     * @test
     */
    public function is_user_can_have_default_role()
    {
        $user = User::factory()->create();
        $roles = $user->roles()->get()->pluck('name')->all();
        $isDefaultUser = Str::of('User')->contains($roles);
        $this->assertTrue($isDefaultUser);

    }
}
