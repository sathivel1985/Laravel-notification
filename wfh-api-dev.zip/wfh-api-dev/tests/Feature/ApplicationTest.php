<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ApplicationTest extends TestCase
{
    protected function setUp(): void {
        parent::setUp();


        //$this->withoutExceptionHandling(); //To get the actual Exception whenever it occurs instead of Laravel handing the exception.

    }
    /**
     *
     * @test
     */
    public function is_application_must_have_type()
    {

        $user = User::first();

        $authorize =$user->createToken('authToken');
        $header =  [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => "Bearer". $authorize->accessToken
        ];

        $response = $this->actingAs($user,'api')->post('api/users/'.$user->id.'/applications',$header)
        ->assertStatus(self::HTTP_UNPROCESSABLE_ENTITY)
        ->assertJsonStructure(['errors'=>['type']]);
    }
    /**
     *
     * @test
     */
    public function is_application_must_have_reason()
    {

        $user = User::first();

        $authorize =$user->createToken('authToken');
        $header =  [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => "Bearer". $authorize->accessToken
        ];

        $response = $this->actingAs($user,'api')->post('api/users/'.$user->id.'/applications',$header)
        ->assertStatus(self::HTTP_UNPROCESSABLE_ENTITY)
        ->assertJsonStructure(['errors'=>['wfh_application_reason_id']]);
    }

    /**
     *
     * @test
     */
    public function is_application_must_have_location()
    {
        $user = User::first();

        $authorize =$user->createToken('authToken');
        $header =  [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => "Bearer". $authorize->accessToken
        ];

        $response = $this->actingAs($user,'api')->post('api/users/'.$user->id.'/applications',$header)
        ->assertStatus(self::HTTP_UNPROCESSABLE_ENTITY)
        ->assertJsonStructure(['errors'=>['wfh_location_id']]);
    }
}
