<?php
return [
    /**
     * Front end 
     */
    'font_end_api' => ENV('FRONT_END_API', null),
];