<?php

use App\Http\Controllers\Api\Admin\Country\CountryuserController;
use App\Http\Controllers\Api\Admin\Country\CountryController;
use App\Http\Controllers\Api\Admin\Country\CountryListController;
use App\Http\Controllers\Api\Admin\Country\CountryOfficeLocationController;
use App\Http\Controllers\Api\Admin\Country\CountryOfficeLocationSummary;
use App\Http\Controllers\Api\Admin\Department\DepartmentController;
use App\Http\Controllers\Api\Admin\Department\DepartmentUserController;
use App\Http\Controllers\Api\Admin\Holiday\OfficeLocationHolidayController;
use App\Http\Controllers\Api\Admin\Manager\ManagerController;
use App\Http\Controllers\Api\Admin\Manager\ManagerUserController;
use App\Http\Controllers\Api\Admin\Manager\ManagerUserLogController;
use App\Http\Controllers\Api\Admin\Permission\PermissionController;
use App\Http\Controllers\Api\Admin\Role\RoleController;
use App\Http\Controllers\Api\Admin\Role\RolePermissionController;
use App\Http\Controllers\Api\Admin\User\UserController;
use App\Http\Controllers\Api\Admin\User\UserLogController;
use App\Http\Controllers\Api\Admin\User\UserRoleController;
use App\Http\Controllers\Api\Admin\User\UserWfhTeamController;
use App\Http\Controllers\Api\Notifications\NotificationController;
use App\Http\Controllers\Api\Reports\AuditSectionQuestionAnswerReport;
use App\Http\Controllers\Api\Reports\WFHReport;
use App\Http\Controllers\Api\WFH\Applications\ApplicationController;
use App\Http\Controllers\Api\WFH\Applications\ApplicationSettingController;
use App\Http\Controllers\Api\WFH\Applications\ManagerApplicationController;
use App\Http\Controllers\Api\WFH\Applications\UserApplicationController;
use App\Http\Controllers\Api\WFH\AuditDuration\AuditDurationController;
use App\Http\Controllers\Api\WFH\AuditSections\AuditSectionAnswerController;
use App\Http\Controllers\Api\WFH\AuditSections\AuditSectionQuestionController;
use App\Http\Controllers\Api\WFH\CoWorkingSpace\CoWorkingSpaceController;
use App\Http\Controllers\Api\WFH\CoWorkingSpace\OfficeLocationCoWorkingSpace;
use App\Http\Controllers\Api\WFH\Locations\LocationController;
use App\Http\Controllers\Api\WFH\Schedules\SchedulesController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\Google2FAController;
use App\Http\Controllers\Auth\RequestPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\Api\WFH\Locations\UserLocationController;
use App\Http\Controllers\Api\WFH\Locations\UserLocationEvaluationController;
use App\Http\Controllers\Api\WFH\PolicyBuilder\PolicyBuilderController;
use App\Http\Controllers\Api\WFH\PolicyBuilder\PolicyBuilderTeamController;
use App\Http\Controllers\Api\WFH\PolicyBuilder\TeamUserAllocationController;
use App\Http\Controllers\Api\WFH\PolicyBuilder\TeamWeekAllocationController;
use App\Http\Controllers\Api\WFH\Questionaries\QuestionaryController;
use App\Http\Controllers\Api\WFH\Questionaries\QuestionarySectionController;
use App\Http\Controllers\Api\WFH\Questionaries\UserQuestionarieSectionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

Route::post('auth/login', [AuthController::class, 'login'])->name('auth.login');
Route::post('auth/register', [AuthController::class, 'register'])->name('auth.register');
Route::post('auth/request-password', [RequestPasswordController::class, 'requestPassword'])->name('auth.request-password');
Route::post('auth/reset-password', [ResetPasswordController::class, 'resetPassword'])->name('auth.password.reset');
Route::post('auth/2fa/validate', [AuthController::class, 'verify2FA'])->name('auth.2fa')->middleware('auth:api');

Route::prefix('auth')->middleware('auth:api')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])
        ->name('auth.logout');
    Route::get('/2fa/get-key', [Google2FAController::class, 'getTwoFactor'])->name('2fa.get-key');
    Route::post('/2fa/enable', [Google2FAController::class, 'enableTwoFactor'])->name('2fa.enable');
    Route::get('/2fa/disable', [Google2FAController::class, 'disableTwoFactor'])->name('2fa.disable');
});


//Route::get('auth/2fa/validate', 'Auth\AuthController@getValidateToken');
//Route::post('auth/2fa/validate', ['middleware' => 'throttle:5', 'uses' => 'Auth\AuthController@postValidateToken']);

// middleware auth:api is applied for the below routes thrugh controller

/**
 * User Role Route
 */
Route::apiResource('users.roles', UserRoleController::class)->only(['index', 'store', 'destroy']);
Route::post('users/upload', [UserController::class, 'importUser'])->name('users.upload');
Route::get('user/profile', [UserController::class, 'show'])->name('users.show');
Route::get('user/profile/{user}', [UserController::class, 'show'])->name('users.showbyuser');
Route::get('users', [UserController::class, 'index'])->name('users.index');
Route::put('users/{user}', [UserController::class, 'update'])->name('users.update');
Route::post('users/create-user', [UserController::class, 'store'])->name('users.new');
Route::get('admin-users', [UserController::class, 'adminUsers'])->name('users.admin-users');
Route::get('users/office-location/{officeLocation}', [UserController::class, 'userList'])->name('users.office-location.list');
Route::get('users-wfh-team-list/{user}',UserWfhTeamController::class);
Route::delete('users/{user}', [UserController::class,'destroy'])->name('users.delete');
Route::post('users/upload-profile-image/{user}', [UserController::class,'uploadProfilePicture'])->name('users.profile.picture');
Route::post('users/status/{user}', [UserController::class,'updateStatus'])->name('users.status');
Route::post('users/change-password/{user}', [UserController::class, 'changePassword'])->name('users.changepassword');
/**
 * Roles,Permission  Routes
 */
Route::apiResource('roles.permissions', RolePermissionController::class)->only(['index', 'store', 'destroy']);
Route::apiResources([
    'roles' => RoleController::class,
    'permissions' => PermissionController::class,
]);

/**
 * User Location Routes
 */
Route::apiResource('users.locations', UserLocationController::class);
Route::post('location-status-update', [LocationController::class, 'updateStatus'])->name('location.update_status');
Route::get('location/{location}', [LocationController::class, 'show'])->name('location.show');
Route::get('user-approved-locations/{user}', [UserLocationController::class, 'approvedLocations'])->name('users.approved.locations');

/**
 * Questionaries,Audit section
 */
Route::get('questionaries/office-locations/{office_location}', [QuestionaryController::class, 'index']);
Route::apiResource('questionaries', QuestionaryController::class)->except(['index']);
Route::apiResource('questionaries.audit-sections', QuestionarySectionController::class);
Route::get('user-questionaries-sections/{office_location}', UserQuestionarieSectionController::class);
Route::post('reorder-audit-sections', [QuestionarySectionController::class, 'updateSortNumber'])->name('audit-sections.reorder');
/**
 * Audit Section Question Routes
 */
//Route::apiResource('audit-sections',AuditSectionController::class);
Route::apiResource('audit-sections.questions', AuditSectionQuestionController::class);

/**
 * User Location Evaluation Routes
 */
Route::post('user-location-evaluations/{wfh_location}', [UserLocationEvaluationController::class, 'store'])->name('user.location.evaluation');
Route::get('user-location-evaluations/{wfh_location}', [UserLocationEvaluationController::class, 'index'])->name('user.location.evaluation.list');

/**
 * Audit answers Routes
 */
Route::apiResource('audit-check-answers', AuditSectionAnswerController::class)->only(['store']);
Route::post('audit-check', [AuditSectionAnswerController::class, 'auditCheck'])->name('audit-answer.check');
Route::post('audit-evaluation', [AuditSectionAnswerController::class, 'auditEvaluation'])->name('audit-answer.evaluation');
/**
 * Audit Duration Routes
 */
Route::apiResource('audit-durations', AuditDurationController::class);

/**
 * Schedules Routes
 */
Route::get('active-schedules', [SchedulesController::class, 'activeSchedule'])->name('schedule.active');
Route::apiResource('schedules', SchedulesController::class)->only(['index', 'update']);

/**
 * Managers , Manager users
 */
Route::apiResource('managers', ManagerController::class)->only(['index', 'store', 'destroy']);
Route::apiResource('managers.users', ManagerUserController::class)->only(['index', 'store', 'destroy']);
Route::post('mangers/mass-user-update', [ManagerUserController::class, 'massUpdate'])->name('manger.user.update');
Route::get('managers/users/{user}', [ManagerUserController::class,'mangersByUserId'])->name('managers.users.list');
Route::apiResource('managers.user-logs', ManagerUserLogController::class)->except(['update']);
Route::post('managers/leaving-request', [ManagerUserLogController::class,'leavingUser'])->name('managers.user.leaving');
/**
 * Application Routes
 */
Route::get('application-types', ApplicationSettingController::class);
Route::apiResource('users.applications', UserApplicationController::class)->only(['index', 'store', 'destroy', 'show']);
Route::get('applications', ApplicationController::class);
Route::apiResource('managers.applications', ManagerApplicationController::class);

/**
 * Country, Office Location Route
 */
Route::apiResource('countries', CountryController::class);
Route::apiResource('country-lists', CountryListController::class);
Route::apiResource('countries.office-locations', CountryOfficeLocationController::class);
Route::get('countries-office-location-list/{country}',CountryOfficeLocationSummary::class);
Route::get('countries-users-list/{country}',CountryuserController::class);
/**
 * Departments
 */
Route::get('department-by-country/{country}', [DepartmentController::class, 'departmentByCountry'])->name('department.country.list');
Route::get('department-by-office-location/{officeLocation}', [DepartmentController::class, 'departmentByOfficeLocation'])->name('department.officelocation.list');
Route::get(
    'departments/managers/office-location/{officeLocation}',
    [DepartmentController::class, 'listOfManagerByOfficeLocation']
)->name('department.managers.officelocation.list');

Route::apiResource('departments', DepartmentController::class);
Route::get('departments/users/{department}', DepartmentUserController::class)->name('department.users.list');
/**
 * Policy Builders
 */
Route::get('policy-builders/{office_location}', [PolicyBuilderController::class, 'index'])->name('policy-builder.list');
Route::apiResource('policy-builders', PolicyBuilderController::class)->except(['index']);
Route::apiResource('policy-builders.teams', PolicyBuilderTeamController::class)->only(['index', 'update']);

/**
 * Team Week Allocation Routes
 */
Route::get('team-week-allocation/{team}', [TeamWeekAllocationController::class, 'index'])->name('team.weekallocation.list');
Route::put('team-week-allocation/{team_allocation}', [TeamWeekAllocationController::class, 'update'])->name('team.weekallocation.update');

/**
 * Team user Allocation
 */
Route::apiResource('team.user-allocation', TeamUserAllocationController::class)->only(['index', 'destroy']);
Route::post('team/{team}', [TeamUserAllocationController::class, 'store'])->name('team.user.store');
Route::post('team-user-upload', [TeamUserAllocationController::class, 'uploadTeamUsers'])->name('team.user.upload');

/**
 * Holiday Routes
 */
Route::apiResource('office-location.holiday', OfficeLocationHolidayController::class)->except(['store']);
Route::post('holiday', [OfficeLocationHolidayController::class,'store'])->name('holiday.store');
Route::get('holiday/country/{country}',[OfficeLocationHolidayController::class,'listHolidayByCountry'])->name('holiday.country.list');

/**
 * CoWorkSpace Routes
 */
Route::apiResource('co-working-spaces', CoWorkingSpaceController::class)->except(['index']);
Route::get('office-locations/{office_location}/co-working-spaces', OfficeLocationCoWorkingSpace::class);

/**
 * User Log Routes
 */
Route::get('user-logs/{officeLocation}',[UserLogController::class, 'index'])->name('userlog.officelocation.list');
Route::apiResource('user-logs', UserLogController::class)->only(['update','show']);
/**
 * Notifications Routes
 */
Route::get('notifications/unread',[NotificationController::class,'unread'])->name('notification.unread');
Route::get('notifications/all',[NotificationController::class,'index'])->name('notification.all');
Route::post('notifications/mark-as-read', [NotificationController::class,'markAsRead'])->name('notification.mark.read');

/**
 * Reports
 */
Route::post('audit-sections/answer-reports', AuditSectionQuestionAnswerReport::class)->name('audit-sections.report');
Route::get('wfh/current-report', [WFHReport::class, 'todayWfhAndWfoReport'])->name('wfh.current-report');

Route::post('wfh/scheduling-report', [WFHReport::class, 'schedulingReport'])->name('wfh.scheduling-report');
