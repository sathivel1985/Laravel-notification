@component('mail::message')
# Hello!

{{ $data['message'] }}


Thanks,<br>
{{ config('app.name') }}
@endcomponent
