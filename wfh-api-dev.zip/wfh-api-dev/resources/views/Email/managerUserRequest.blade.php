@component('mail::message')
# Hello!

{{ $data['message'] }}

@component('mail::button', ['url' =>   $data['front_end_url']  ])
Please click here access
@endcomponent



Thanks,<br>
{{ config('app.name') }}
@endcomponent
