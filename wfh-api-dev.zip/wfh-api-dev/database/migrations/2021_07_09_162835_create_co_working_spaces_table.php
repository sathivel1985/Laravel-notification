<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCoWorkingSpacesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('co_working_spaces', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->mediumText('address');
            $table->double('distance')->nullable();
            $table->foreignId('office_location_id')->constrained('office_locations');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('co_working_spaces');
    }
}
