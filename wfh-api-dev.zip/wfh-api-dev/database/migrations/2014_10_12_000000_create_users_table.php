<?php

use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $userDefault = array_flip(User::STATUS)['in-active'];
        Schema::create('users', function (Blueprint $table) use ($userDefault) {
            $table->bigIncrements('id');
            $table->string('preferred_name');
            $table->string('first_name',100)->nullable(true);
            $table->string('last_name',100)->nullable(true);
            $table->string('designation',100)->nullable();
            $table->string('email',100)->unique();
            $table->string('password')->nullable();
            $table->string('personal_email',100)->nullable(true);
            $table->string('gender_pronoun',30)->nullable(true);
            $table->timestamp('email_verified_at')->nullable();
            $table->string('google2fa_secret',100)->nullable();
            $table->unsignedInteger('status')->default($userDefault)->comment('10 is active and 20 is in-active');
            $table->date('joining_date')->nullable();
            $table->date('leaving_date')->nullable();
            $table->string('picture',250)->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
