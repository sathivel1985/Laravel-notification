<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddUserLocationEvaluationIdToWfhLocationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('wfh_locations', function (Blueprint $table) {
            $table->foreignId('user_location_evaluation_id')->nullable()->constrained('user_location_evaluations');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('wfh_locations', function (Blueprint $table) {
            $table->dropColumn('user_location_evaluation_id');
        });
    }
}
