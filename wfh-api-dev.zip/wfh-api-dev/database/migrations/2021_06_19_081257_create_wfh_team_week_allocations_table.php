<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWfhTeamWeekAllocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wfh_team_week_allocations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('wfh_team_id')->constrained('wfh_teams');
            $table->year('year')->nullable();
            $table->integer('week_number')->nullable();
            $table->date('date')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wfh_team_week_allocations');
    }
}
