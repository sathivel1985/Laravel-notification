<?php

use App\Models\WfhApplication;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWfhApplicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wfh_applications', function (Blueprint $table) {
            $table->id();
            $table->string('type',30);
            $table->string('state',10);
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->json('recurring_days')->nullable();
            $table->foreignId('wfh_location_id')->nullable()->constrained('wfh_locations');
            $table->foreignId('wfh_application_reason_id')->constrained('wfh_application_reasons');
            $table->string('reason_other',100)->nullable();
            $table->string('location_status',50)->nullable();
            $table->foreignId('user_id')->constrained('users');
            $table->foreignId('approver_id')->nullable()->constrained('users');
            $table->date('status_date')->nullable();
            $table->string('status',5)->default(array_flip(WfhApplication::STATUS)['PENDING']);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wfh_applications');
    }
}
