<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddHiddingQuestionToWfhAuditSectionQuestionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('wfh_audit_section_questions', function (Blueprint $table) {
            $table->json('hiding_question')->nullable()->after('mandatory');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('wfh_audit_section_questions', function (Blueprint $table) {

            $table->dropColumn('hiding_question');
        });
    }
}
