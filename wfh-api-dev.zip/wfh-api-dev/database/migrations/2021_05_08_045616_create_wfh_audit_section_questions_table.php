<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWfhAuditSectionQuestionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wfh_audit_section_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('wfh_audit_section_id')->constrained('wfh_audit_sections');
            $table->string('question',500);
            $table->string('ideal_answer',10)->nullable();
            $table->double('ideal_answer_weightage',8,2)->nullable();
            $table->boolean('mandatory');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wfh_audit_section_questions');
    }
}
