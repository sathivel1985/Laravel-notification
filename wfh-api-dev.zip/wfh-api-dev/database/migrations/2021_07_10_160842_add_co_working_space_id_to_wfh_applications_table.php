<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddCoWorkingSpaceIdToWfhApplicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('wfh_applications', function (Blueprint $table) {
            $table->foreignId('co_working_space_id')->nullable()->constrained('co_working_spaces');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('wfh_applications', function (Blueprint $table) {
            $table->dropColumn('co_working_space_id');
        });
    }
}
