<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWfhTeamUserAllocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wfh_team_user_allocations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('wfh_team_id')->constrained('wfh_teams');
            $table->foreignId('user_id')->constrained('users');
            $table->boolean('is_essential')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wfh_team_user_allocations');
    }
}
