<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePolicyBuildersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('policy_builders', function (Blueprint $table) {
            $table->id();
            $table->integer('perm_state')->comment('10 is wfh and 20 is wfo');
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->integer('occupancy')->nullable();
            $table->integer('execution')->nullable()->comment('10 is team and 20 is department');
            $table->integer('frequency')->nullable()->comment('10 is week and 20 is days');
            $table->string('teams')->nullable();
            $table->string('recurring_days')->nullable();
            $table->foreignId('user_id')->constrained('users');
            $table->boolean('essential_list')->nullable();
            $table->foreignId('office_location_id')->constrained('office_locations');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('policy_builders');
    }
}
