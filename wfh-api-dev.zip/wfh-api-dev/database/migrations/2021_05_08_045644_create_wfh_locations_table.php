<?php

use App\Models\WfhLocation;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWfhLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wfh_locations', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->mediumText('address');
            $table->foreignId('user_id')->constrained('users');
            $table->string('status')->nullable();
            $table->dateTime('overriden_at')->nullable();
            $table->foreignId('overriden_by')->nullable()->constrained('users');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wfh_locations');
    }
}
