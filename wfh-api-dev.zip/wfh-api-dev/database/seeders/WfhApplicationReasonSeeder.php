<?php

namespace Database\Seeders;

use App\Models\WfhApplicationReason;
use Illuminate\Database\Seeder;

class WfhApplicationReasonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $reasons = [
            ['name'	=> 'Others','state'=>'wfh','sort_no'=>'100'],
            ['name'	=> 'Others', 'state' => 'wfo', 'sort_no'=>'101'],
            ['name'  => 'Covid-19 related reasons','state'=>'wfh','sort_no'=>'1'],
            ['name'	=> 'Living with children or elderly','state'=>'wfh','sort_no'=>'2'],
            ['name'	=> 'Health or medical reasons','state'=>'wfh','sort_no'=>'3'],
            ['name'	=> 'Travel-related reasons','state'=>'wfh','sort_no'=>'4'],
            ['name'	=> 'VPN is required', 'state' => 'wfo','sort_no'=>'1'],
            ['name'	=> 'Due to living place', 'state' => 'wfo', 'sort_no'=>'2'],
        ];
        foreach ($reasons as $reason) {
            WfhApplicationReason::create([
                'name' 		=> $reason["name"],
                'state'     => $reason["state"],
                'sort_no'   =>  $reason["sort_no"]
            ]);
        }
    }
}
