<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

        $this->call([
            CountryListSeeder::class,
            CountrySeeder::class,
            RoleSeeder::class,
            UserSeeder::class,
            PermissionsSeeder::class,
            WfhScheduleSeeder::class,
            WfhAuditDurationSeeder::class,
            WfhAuditSectionTemplateSeeder::class,
            WfhApplicationReasonSeeder::class,
            WfhLocationSeeder::class,
            
    	]);
    }
}
