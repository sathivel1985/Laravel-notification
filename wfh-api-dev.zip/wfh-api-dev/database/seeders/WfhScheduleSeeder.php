<?php

namespace Database\Seeders;

use App\Models\WfhSchedule;
use Illuminate\Database\Seeder;

class WfhScheduleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $schedules = [

            //    ['name' => 'admin','description'=>'Admin'],
            //    ['name'	=> 'manager','description'=>'MANAGER'],
               ['name' => 'Ad-hoc WFH(Default)','description'=>'All employees work from the office, but able to apply for WFH as needed','is_active'=>1,'name_value'=>'AD_HOC'],
               ['name' => 'Activate Rostering','description'=>'Activate Rostering','is_active'=>0,'name_value'=>'ROSTERING'],
               ['name' => 'Activate Permanent Work-From-Home for the entire Organisation','description'=>'All employees will not be allowed to work in the office','is_active'=>0,'name_value'=>'PERMANENT'],

           ];
           foreach ($schedules as $schedule) {
               WfhSchedule::create([
                   'name' 		 => $schedule["name"],
                   'description' => $schedule["description"],
                   'is_active'   => $schedule["is_active"] ?? null,
                   'name_value'  => $schedule['name_value']
               ]);
           }
    }
}
