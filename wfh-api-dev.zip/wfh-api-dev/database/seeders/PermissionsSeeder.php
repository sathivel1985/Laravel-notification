<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissions = [
               ['name'  => 'ADD-EMPLOYEE','description'=>'Create Employee'],
               ['name'  => 'HUMAN-RESOURCE','description'=>'HR permissions'],
               ['name'	=> 'UPDATE-EMPLOYEE','description'=>'Update Employee'],
               ['name'  => 'UPLOAD-EMPLOYEE','description'=>'Upload Employees'],
               ['name'	=> 'DELETE-EMPLOYEE','description'=>'Delete Employee'],
               ['name'  => 'MANAGE-POLICYBUILDER','description'=>'Manager Policybuilder'],
               ['name'	=> 'MANAGE-ROLE','description'=>'Manage Role '],
               ['name'	=> 'MANAGE-COMPANY','description'=>'Manager Company'],
               ['name'	=> 'MANAGE-TEAM','description'=>'Manage Team'],
               ['name'	=> 'MANAGE-DEPARMENT','description'=>'Manage Department'],
               ['name'	=> 'MANAGE-CALENDAR','description'=>'Manage Calendar'],
               ['name'	=> 'MANAGE-QUESTIONAIRE','description'=>'Manage Questionaire'],
               ['name'  => 'HR','description' => 'HR']
           ];
           foreach ($permissions as $role) {
               Permission::create([
                   'name' 		 => $role["name"],
                   'description' => $role["description"],
               ]);
           }
    }
}
