<?php

namespace Database\Seeders;

use App\Models\WfhAuditDuration;
use Illuminate\Database\Seeder;

class WfhAuditDurationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $durations = [
            ['duration'  => 'Every 3 Months','is_active'=>1],
            ['duration'	=> 'Every 6 Months','is_active'=>0],
            ['duration'	=> 'Every 12 Months','is_active'=>0]
        ];
        foreach ($durations as $duration) {
            WfhAuditDuration::create([
                'duration' 		=> $duration["duration"],
                'is_active'     => $duration['is_active']
            ]);
        }
    }
}
