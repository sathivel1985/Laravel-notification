<?php

namespace Database\Seeders;

use App\Models\WfhAuditSectionTemplate;
use Illuminate\Database\Seeder;

class WfhAuditSectionTemplateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sections = [
            [
                'name' => 'Audit Duration', 'icon' => null, 'content' => null,
                'format' => 'schedule', 'description' => null,'sort_no'=> 1
            ],
            [
                'name' => 'General insurance coverage', 'icon' => null, 'content' => null,
                'format' => 'question', 'description' => null,'sort_no'=> 2
            ],
            [
                'name' => 'General WFH safety and health', 'icon' => null, 'content' => null,
                'format' => 'question', 'description' => null,'sort_no'=> 3
            ],
            [
                'name' => 'General conduciveness of home workstation', 'icon' => null, 'content' => null,
                'format' => 'question', 'description' => 'Is the computer you are using at home for WFH purposes','sort_no'=> 4
            ],
            [
                'name' => 'General IT equipment', 'icon' => null, 'content' => null,
                'format' => 'question', 'description' => null,'sort_no'=> 5
            ],
            [
                'name' => 'General awareness of cybersecurity',
                'icon' => null,
                'description' => null,
                'format' => 'text',
                'content' => null,
                'sort_no'=> 6
            ],
            [
                'name' => 'Confirmation',
                'icon' => null,
                'content' => "I confirm that all the information provided is true",
                'format' => 'text',
                'description' => null,
                'sort_no'=> 7
            ],
        ];
        foreach ($sections as $section) {
            WfhAuditSectionTemplate::create([
                'name'          => $section["name"],
                'description'   => $section["description"],
                'content'       => $section["content"],
                'format'        => $section["format"],
                'icon'          => $section["icon"],
                'sort_no'       => $section["sort_no"],
            ]);
        }
    }
}
