<?php

namespace Database\Seeders;

use App\Models\Country;
use App\Models\OfficeLocation;
use Illuminate\Database\Seeder;


class CountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $countries = [
            [
                'name' => 'Singapore','entity' => 'Origin Pte Ltd',
                'officeLocation' => [
                    [
                    'name' => 'SIM LIM TOWER',
                    'address' => '2, #03-4567, NORTH BRIDGE ROAD, SINGAPORE 123470'
                    ],
                    [
                        'name' => 'DOVER TOWER ',
                        'address' => '2, #020-234, DOVER ROAD ROAD, SINGAPORE 567870'
                    ]
                ]
            ],
            [
                'name' => 'Malaysia', 'entity' => 'OneSMS Pte Ltd',
                'officeLocation' => [
                    [
                    'name' => 'Angsana Johor Bahru Mall',
                    'address' => 'L3-31A LEVEL 3, ANGSANA JOHOR BAHRU MALL,
                    81200 JOHOR BAHRU, 81200 Johor Bahru, Johor, Malaysia'
                    ]
                ]
            ]
        ];
        foreach ($countries as $country) {
            $countryInserted = Country::create([
                'name'     => $country["name"],
                'entity'   => $country["entity"]
            ]);
            foreach($country['officeLocation'] as $location) {
                $locationData[] = new OfficeLocation($location);
            }
            $countryInserted->officeLocations()->saveMany($locationData);
            unset($locationData);
        }
    }
}
