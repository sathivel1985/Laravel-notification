<?php

namespace Database\Seeders;

use App\Models\WfhLocation;
use Illuminate\Database\Seeder;

class WfhLocationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $locations = [
            ['user_id'=>'1','name'  => 'Clementi','address' => 'BLK 304, CLEMENTI AVE 4, #03-495, SINGAPORE 120304'],
            ['user_id'=>'1','name'	=> 'WHAMPOA','address'=>'BLK 101, WHAMPOA DRIVE, #07-175, SINGAPORE 101230'],
        ];
        foreach ($locations as $location) {
            WfhLocation::create([
                'name' 	  => $location["name"],
                'user_id' => $location["user_id"],
                'address' => $location['address']
            ]);
        }
    }
}
