<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $roles = [
            ['name' => 'admin', 'description' => 'Admin user', 'is_default' =>  null],
            ['name' => 'manager', 'description' => 'Manager role', 'is_default' =>  null],
            ['name' => 'user', 'description' => 'Default user', 'is_default' => 1]
        ];
        foreach ($roles as $role) {
            Role::create([
                'name'          => $role["name"],
                'description' => $role["description"],
                'is_default'  => $role["is_default"] ?? 0,
            ]);
        }
    }
}
