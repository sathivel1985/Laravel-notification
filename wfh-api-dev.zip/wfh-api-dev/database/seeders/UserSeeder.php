<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin = [3, 1];
        $manager = [3, 2];
        $userRole = [3];

        $users =
            [
                [
                    'preferred_name' => 'Admin',
                    'first_name'     => 'admin',
                    'last_name'      => 'admin',
                    'email' => 'admin@otech.com.sg',
                    'designation'    => 'System Admin',
                    'personal_email' => 'admin@otech.com.sg',
                    'gender_pronoun' => 'He',
                    'email_verified_at' => now(),
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                    'remember_token' => Str::random(10),
                    'role' => $admin,
                    'picture' => '',
                    'status'  => 'active'
                ],
                [
                    'preferred_name' => 'Lionel',
                    'first_name'     => 'Lionel',
                    'last_name'      => 'Otsuka',
                    'designation'    => 'Manager',
                    'personal_email' => 'sglioots@otsukatechnology.com',
                    'gender_pronoun' => 'He',
                    'email' => 'sglioots@otsukatechnology.com',
                    'email_verified_at' => now(),
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                    'remember_token' => Str::random(10),
                    'role' => $admin,
                    'picture' => '',
                    'status'  => 'active'
                ],
                [
                    'preferred_name' => 'Iqbal',
                    'first_name'     => 'Iqbal',
                    'last_name'      => 'Mohd',
                    'designation'    => 'Manager',
                    'personal_email' => 'wfh-manager@otech.com.sg',
                    'gender_pronoun' => 'He',
                    'email' => 'wfh-manager@otech.com.sg',
                    'email_verified_at' => now(),
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                    'remember_token' => Str::random(10),
                    'role' => $manager,
                    'picture' => '',
                    'status'  => 'active'
                ],
                [
                    'preferred_name' => 'William',
                    'first_name'     => 'William',
                    'last_name'      => 'Chew',
                    'designation'    => 'Employee',
                    'personal_email' => 'wfh-user@otech.com.sg',
                    'gender_pronoun' => 'He',
                    'email' => 'wfh-user@otech.com.sg',
                    'email_verified_at' => now(),
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                    'remember_token' => Str::random(10),
                    'role' => $userRole,
                    'picture' => '',
                    'status'  => 'active'
                ],
                [
                    'preferred_name' => 'Origin',
                    'first_name'     => 'Origin',
                    'last_name'      => 'Tech',
                    'designation'    => 'Director',
                    'personal_email' => 'wfh-admin@otech.com.sg',
                    'gender_pronoun' => 'He',
                    'email' => 'wfh-admin@otech.com.sg',
                    'email_verified_at' => now(),
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                    'remember_token' => Str::random(10),
                    'role' => $admin,
                    'picture' => '',
                    'status'  => 'active'
                ]

            ];
        foreach ($users as $user) {
            $createdUser = User::create([
                'preferred_name'         => $user["preferred_name"],
                'first_name'             =>  $user["first_name"],
                'last_name'              => $user["last_name"],
                'email'                  => $user["email"],
                'personal_email'         =>  $user["personal_email"],
                'email_verified_at'      => $user["email_verified_at"],
                'password'               => $user["password"],
                'remember_token'         =>  $user["remember_token"],
                'office_location_id'     => 1,
                'picture'                => '',
                'status'                 =>  $user["status"]
            ]);
            $createdUser->roles()->sync($user['role']);
        }
    }
}
