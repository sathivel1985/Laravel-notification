<?php

namespace Database\Factories;

use App\Models\WfhTeams;
use Illuminate\Database\Eloquent\Factories\Factory;

class WfhTeamsFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = WfhTeams::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
