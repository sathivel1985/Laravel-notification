<?php

namespace Database\Factories;

use App\Models\Questionary;
use Illuminate\Database\Eloquent\Factories\Factory;

class QuestionaryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Questionary::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
