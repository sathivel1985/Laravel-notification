<?php

namespace Database\Factories;

use App\Models\WfhTeamWeekAllocation;
use Illuminate\Database\Eloquent\Factories\Factory;

class WfhTeamWeekAllocationFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = WfhTeamWeekAllocation::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
