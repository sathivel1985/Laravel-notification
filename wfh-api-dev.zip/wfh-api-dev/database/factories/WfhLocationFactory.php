<?php

namespace Database\Factories;

use App\Models\WfhLocation;
use Illuminate\Database\Eloquent\Factories\Factory;

class WfhLocationFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = WfhLocation::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
