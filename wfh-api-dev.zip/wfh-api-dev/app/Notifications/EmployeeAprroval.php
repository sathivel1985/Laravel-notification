<?php

namespace App\Notifications;

use App\Models\UserLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class EmployeeAprroval extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(UserLog $userLog)
    {
        $userLog = $userLog->load(['user','requestor','approver']);
        $message = "Your ";

        $subject = "";
        if(strtolower($userLog->type) == 'joining'){
            $subject = "New employee request";
        }
        if(strtolower($userLog->type) == 'leaving'){
            $subject =' has requested to remove employee ' . ucfirst($userLog->user->first_name);
        }

        if(strtolower($userLog->status) == 'approved'){
            $message .=' request is approved ' ;
        }
        if(strtolower($userLog->status) == 'rejected'){
            $message .=' request is rejected ' ;
        }

        $this->data = [
            'type'       => 'EmployeeApproval',
            'subject'    => $subject,
            'message'    => $message,
            // 'api_url'        => url("/api/user-logs/{$userLog->id}"),
            // 'front_end_url'  => config('custom.font_end_api')."api/user-logs/{$userLog->id}",
            'user_log_id'=> $userLog->id
         ];
        $this->userLog = $userLog;
        $this->notification_type = "employee";
        $this->redirect = 0;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)->markdown(
            'Email.employeeApproval', ['data' =>  $this->data]
        );
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
    public function toDatabase($notifiable)
    {
        return $this->data;
    }
}
