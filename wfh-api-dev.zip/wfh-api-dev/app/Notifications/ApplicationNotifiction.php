<?php

namespace App\Notifications;

use App\Models\WfhApplication;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ApplicationNotifiction extends Notification
{
    use Queueable;

    public $application;
    public $data = [];

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(WfhApplication $application, $userType = null)
    {
     //   $application = $application->load(['user','approver']);

        $type = "";
        $subject = "";
        if (strtolower($userType) == 'manager') {
            $message = ucfirst($application->approver->first_name).' has  ' .strtolower($application->status).' your application';
            $subject = "Application status update";
        }
        if (strtolower($userType) == 'user') {
            $message = ucfirst($application->user->first_name).' has request for your approval.';
            $subject = "New application request";
        }

        $this->data = [
            'type'          => 'Application',
            'subject'       => $subject,
            'message'       => $message,
            // 'api_url'        => url("/api/applications/{$application->id}"),
            // 'front_end_url'  => config('custom.font_end_api')."api/applications/{$application->id}",
            'user_id'=> $application->user->id,
            'approver_user_id' => $application->approver->id ?? null
         ];
        $this->application = $application;
        $this->notification_type = "application";
        $this->redirect = 1;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)->markdown(
            'Email.applicationNotification', ['data' =>  $this->data]
        );
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
    public function toDatabase($notifiable)
    {
        return $this->data;
    }
}
