<?php

namespace App\Notifications;

use App\Models\User;
use App\Models\UserLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class EmployeeRequest extends Notification
{
    use Queueable;

    public $userLog;
    public $data = [];
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(UserLog $userLog)
    {
        $userLog = $userLog->load(['user','requestor']);
        $message = ucfirst($userLog->requestor->first_name);
        $type = "";
        $subject = "";
        if(strtolower($userLog->type) == 'joining'){
            $message .=' has requested to add new  employee ' .ucfirst($userLog->user->first_name);
            $subject = "New employee request";
        }
        if(strtolower($userLog->type) == 'leaving'){
            $message .=' has requested to remove employee ' . ucfirst($userLog->user->first_name);
            $subject = "Leaving employee request";
        }

        $this->data = [
            'type'       => 'UserRequest',
            'subject'    => $subject,
            'message'    => $message,
            // 'api_url'        => url("/api/user-logs/{$userLog->id}"),
            // 'front_end_url'  => config('custom.font_end_api')."api/user-logs/{$userLog->id}",
            'user_log_id'=> $userLog->id
         ];
        $this->userLog = $userLog;
        $this->notification_type = "employee";
        $this->redirect = 1;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        //return ['database','mail'];
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)->markdown(
            'Email.managerUserRequest', ['data' =>  $this->data]
        );
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }

    public function toDatabase($notifiable)
    {
        return $this->data;
    }
}
