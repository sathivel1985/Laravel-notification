<?php
namespace App\Traits;

trait ApiResponseTrait {
    protected $error_message = ['error' => true];
    protected function success($data, $code = 200 ){
        return response()->json($data, $code );
    }
    protected function error($error,$code = 400)
    {
        return response()->json(['errors' => $error], $code);
    }
    protected function customResponse($data, $code = 200)
    {
        return response()->json(['data'=>$data],$code);
    }
}
