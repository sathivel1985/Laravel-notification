<?php

namespace App\Console\Commands;

use App\Models\FiscalCalendar;
use Illuminate\Console\Command;

class FiscalCalendarCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'calendar:fiscal-calendar
    { --start_date= : enter start date }
    { --total= : total days }
    ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fiscal calendar date generation';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $start_date = !empty($this->option('start_date')) ? $this->option('start_date'):'';
        $totalDays = !empty($this->option('total')) ? $this->option('total'):'';
        $this->info('started');
        for($i = 0; $i <= $totalDays; $i++ ){
             $dateTime = strtotime($start_date.'+'.$i.' day');
             $week_number = date('W', $dateTime);
             $year = date('Y', $dateTime);
             $date = date('Y-m-d',$dateTime);

             FiscalCalendar::create([
                 'date' => $date,
                 'year' => $year,
                 'week_number' => $week_number
             ]);
        }
        $this->info('done');
    }
}
