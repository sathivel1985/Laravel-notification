<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OfficeLocation extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'country_id',
        'address'
    ];

    public function country()
    {
        return $this->belongsTo(Country::class);
    }
    public function departments()
    {
        return $this->hasMany(Department::class,'office_location_id','id');
    }
    public function holidays()
    {
        return $this->hasMany(Holiday::class);
    }
    public function users()
    {
        return $this->hasMany(User::class);
    }
    public function coWorkingSpaces()
    {
        return $this->hasMany(CoWorkingSpace::class,'office_location_id','id');
    }

     /**
     * event handlings
     */
    protected static function booted()
    {

        static::deleted(function ($location)  {
            /** Team Users */
            User::where('office_location_id',$location->id)->delete();
            /** User Allocation */
        });

    }
}
