<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WfhTeam extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'name',

    ];

    public function weekAllocations()
    {
        return $this->hasMany(WfhTeamWeekAllocation::class,'wfh_team_id','id');
    }

    public function userAllocations()
    {
        return $this->hasMany(WfhTeamUserAllocation::class,'wfh_team_id','id');
    }

    public function excludeEssentialUserAllocations()
    {
        return $this->hasMany(WfhTeamUserAllocation::class,'wfh_team_id','id')->where('is_essential','1');
    }

    public function policyBuilder(){
        return $this->belongsTo(PolicyBuilder::class);
    }

}
