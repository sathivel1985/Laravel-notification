<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuestionaryOfficeLocation extends Model
{
    use HasFactory;

    protected $fillable = [
        'questionary_id',
        'office_location_id'
    ];

    public function questionary()
    {
        return $this->belongsTo(Questionary::class);
    }
    public function officeLocation()
    {
        return $this->belongsTo(OfficeLocation::class,'office_location_id','id');
    }

}
