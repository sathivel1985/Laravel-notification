<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WfhAuditSectionQuestion extends Model
{
    use HasFactory,SoftDeletes;

     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable =  [
        'question',
        'mandatory',
        'ideal_answer',
        'ideal_answer_weightage',
        'hiding_question',
        'title'
    ];

    protected $casts = [
		'hiding_question' => 'json' // save hiding_question as a json column,
 	];

    public function auditSection()
    {
        return $this->belongsTo(WfhAuditSection::class,'wfh_audit_section_id','id');
    }
    protected static function booted()
    {
        static::creating(function ($model) {
            $model->ideal_answer = $model->ideal_answer ?? 'yes';
            $model->ideal_answer_weightage = $model->ideal_answer_weightage ?? 100.00;
        });

    }
    public function answer()
    {
        return $this->hasMany(WfhAuditSectionAnswer::class);
    }
    public function oneAnswer()
    {
        return $this->hasOne(WfhAuditSectionAnswer::class);
    }

}
