<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class PolicyBuilder extends Model
{
    use HasFactory, SoftDeletes;

    const EXECUTION = [
        '10' => 'team',
        '20' => 'department'
    ];
    const FREQUENCY = [
        '10' => 'weeks',
        '20' => 'days'
    ];
    const PERM_STATE = [
        '10' => 'wfh',
        '20' => 'wfo'
    ];
    const RECURRINGDAYS = [
        '1' => 'Monday',
        '2' => 'Tuesday',
        '3' => 'Wednesday',
        '4' => 'Thursdays',
        '5' => 'Friday',
        '6' => 'Saturday',
        '7' => 'Sunday'
    ];

    protected $fillable = [
        'perm_state',
        'start_date',
        'end_date',
        'occupancy',
        'execution',
        'frequency',
        'teams',
        'recurring_days',
        'user_id',
        'essential_list',
        'office_location_id'
    ];


    public function getStartDateAttribute($value)
    {
        if(!empty($value)){
            return date('d-m-Y',strtotime($value));
        }
    }
    public function setStartDateAttribute($value)
    {
        if(!empty($value)){
            $this->attributes['start_date'] =  date('Y-m-d',strtotime($value));
        }else{
            $this->attributes['start_date'] = null;
        }
    }

    public function getEndDateAttribute($value)
    {
        if(!empty($value)){
            return date('d-m-Y',strtotime($value));
        }
    }
    public function setEndDateAttribute($value)
    {
        if(!empty($value)){
            $this->attributes['end_date'] =  date('Y-m-d',strtotime($value));
        }else{
            $this->attributes['end_date'] = null;
        }
    }

    public function getFrequencyAttribute($value)
    {
        if(!empty($value)){
            return self::FREQUENCY[$value];
        }

    }
    public function setFrequencyAttribute($value)
    {
        if(!empty($value)){
            $this->attributes['frequency'] = array_flip(self::FREQUENCY)[strtolower($value)];
        }else{
            $this->attributes['frequency'] = null;
        }
    }

    public function getExecutionAttribute($value)
    {
        if(!empty($value)){
            return self::EXECUTION[$value];
        }
    }
    public function setExecutionAttribute($value)
    {
        if(!empty($value)){
            $this->attributes['execution'] = array_flip(self::EXECUTION)[strtolower($value)];
        }else{
            $this->attributes['execution'] = null;
        }

    }
    public function getPermStateAttribute($value)
    {
        if(!empty($value)){
            return self::PERM_STATE[$value];
        }
    }
    public function setPermStateAttribute($value)
    {
        $this->attributes['perm_state'] = array_flip(self::PERM_STATE)[strtolower($value)];
    }

    public function setRecurringDaysAttribute($value)
    {
        if (count($value) > 0) {
            $this->attributes['recurring_days'] =  implode(',', $value);
        }else{
            $this->attributes['recurring_days'] = null;
        }
    }

    public function setTeamsAttribute($value)
    {
        if (count($value) > 0) {
            $this->attributes['teams'] =  implode(',', $value);
        }else{
            $this->attributes['teams'] = null;
        }
    }

    public function getRecurringDaysAttribute($value)
    {
        $dayName = [];
        if (!empty($value)) {
            $array = explode(',', $value);
            foreach ($array as $dayKey) {
                $dayName[] =  self::RECURRINGDAYS[$dayKey] ?? null;
            }
        }
        return $dayName;
    }

    public function wfhTeams()
    {
        return $this->hasMany(WfhTeam::class, 'policy_builder_id', 'id');
    }

    public function officeLocation()
    {
        return $this->belongsTo(OfficeLocation::class, 'office_location_id', 'id');
    }

    public function wfhTeamWeekAllocations()
    {
        return $this->hasManyThrough(
            WfhTeamWeekAllocation::class,
            WfhTeam::class,
            'policy_builder_id',
            'wfh_team_id',
            'id',
            'id'
        )->orderBy('wfh_team_week_allocations.week_number')->orderBy('wfh_team_week_allocations.date');
    }
    public function wfhTeamUserAllocations()
    {
        return $this->hasManyThrough(
            WfhTeamUserAllocation::class,
            WfhTeam::class,
            'policy_builder_id',
            'wfh_team_id',
            'id',
            'id'
        );
    }
    public function applications(){
        return $this->hasMany(WfhApplication::class,'policy_builder_id','id');
    }
    public function wfoApplications()
    {
        return $this->hasMany(WfhApplication::class,'policy_builder_id','id')->where('state','wfo');
    }
    public function wfhApplications()
    {
        return $this->hasMany(WfhApplication::class,'policy_builder_id','id')->where('state','wfh');
    }

    public static function getLatestPolicyBuilderByOfficeLocation($officeLocation_id = null, $isFormBuilder = null){

        // if(empty($officeLocation_id)){
        //     $officeLocation_id = Auth::user()->office_location_id;
        // }
        // return self::with(['wfhTeams', 'wfhTeamWeekAllocations.wfhTeam','wfhTeamUserAllocations.user','wfhTeamUserAllocations.wfhTeam'])
        // ->where('office_location_id',$officeLocation_id)
        // ->where(function ($query) {
        //     // $query->whereDate('start','>=', Carbon::today())
        //     // ->orWhereNull('end_date');
        //     $query->whereRaw( "
        //         ( perm_state = 10 AND  '".Carbon::today()->format('Y-m-d'). "' BETWEEN start_date AND end_date )
        //         OR (  perm_state = 20 AND (start_date IS NULL OR end_date IS NULL) )
        //     ");
        // })
        // ->latest()
        // ->first();
        if(empty($officeLocation_id)){
            $officeLocation_id = Auth::user()->office_location_id;
        }
        $builder = self::with(['wfhTeams', 'wfhTeamWeekAllocations.wfhTeam','wfhTeamUserAllocations.user','wfhTeamUserAllocations.wfhTeam'])
        ->where('office_location_id',$officeLocation_id);
        if ($isFormBuilder == 1) {
            $builder= $builder->where(function ($query) {
                $query->whereDate('end_date','>=', Carbon::today())
                ->orWhereNull('end_date');
            });
        } else{
            $builder= $builder->where(function ($query) {
                $query->whereRaw( "
                    ( perm_state = 10 AND  '".Carbon::today()->format('Y-m-d'). "' BETWEEN start_date AND end_date )
                    OR (  perm_state = 20 AND (start_date IS NULL OR end_date IS NULL) )
                ");
            });
        }

        return $builder->latest()
        ->first();

    }
}
