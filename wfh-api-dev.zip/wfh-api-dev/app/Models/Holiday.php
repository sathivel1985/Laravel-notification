<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Holiday extends Model
{
    use HasFactory;

    protected $fillable = [
        'start_date',
        'end_date',
        'category',
        'description',
        'office_location_id',
        'user_id'
    ];

    public function officeLocation()
    {
        return $this->belongsTo(OfficeLocation::class,'office_location_id','id');
    }

    public function user()
    {
        return $this->belongsTo(User::class,'user_id','id');
    }

    public function dates()
    {
        return $this->hasMany(HolidayDates::class);
    }

}
