<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Department extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'office_location_id'
    ];

    public function officeLocation()
    {
        return $this->belongsTo(OfficeLocation::class,'office_location_id','id');
    }

    public function manager()
    {
        return $this->hasOne(Manager::class);
    }

    public function departmentUser()
    {
        return $this->hasManyThrough(
            ManagerUser::class,
            Manager::class,
            'department_id',
            'manager_id',
            'id',
            'id'
        );
    }
}
