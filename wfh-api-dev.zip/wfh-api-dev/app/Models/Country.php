<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Country extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'entity'
    ];

    public function officeLocations()
    {
        return $this->hasMany(OfficeLocation::class);
    }

    public static function boot() {
        parent::boot();

        static::deleting(function($country) { // before delete() method call this
             $country->officeLocations()->delete();
        });
    }
}
