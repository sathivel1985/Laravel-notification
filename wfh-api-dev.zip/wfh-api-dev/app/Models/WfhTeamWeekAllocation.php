<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WfhTeamWeekAllocation extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'wfh_team_id',
        'year',
        'week_number',
        'date'
    ];

    public function wfhTeam()
    {
        return $this->belongsTo(WfhTeam::class, 'wfh_team_id','id');
    }
}
