<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Questionary extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'preferred_name',
        'user_id',
        'countrie_id'
    ];

    public function questionaryOfficeLocations()
    {
        return $this->hasMany(QuestionaryOfficeLocation::class);
    }
    public function sections()
    {
        return $this->hasMany(WfhAuditSection::class)->orderBy('sort_no');
    }

    public static function boot() {
        parent::boot();
        static::created(function($questionary) { // after created() method call this
            $sectionTemplates = WfhAuditSectionTemplate::all();
            $data = [];
            foreach($sectionTemplates AS $sectionTemplate){
                $data[] = new WfhAuditSection([
                    'name'          => $sectionTemplate["name"],
                    'description'   => $sectionTemplate["description"],
                    'content'       => $sectionTemplate["content"],
                    'format'        => $sectionTemplate["format"],
                    'icon'          => $sectionTemplate["icon"],
                    'sort_no'       => $sectionTemplate["sort_no"],
                ]);
            }

            $questionary->sections()->saveMany([
                ...$data
            ]);

        });
        static::deleting(function($questionary) { // after created() method call this

            $questionary->sections()->delete();

        });
    }
}
