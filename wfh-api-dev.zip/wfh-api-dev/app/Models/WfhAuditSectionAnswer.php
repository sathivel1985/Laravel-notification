<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WfhAuditSectionAnswer extends Model
{
    use HasFactory,SoftDeletes;
    const FORMAT_ANSWER = [
        'yes',
        'no'
    ];

    public function getAnswerAttribute($value)
    {
        if(!empty($value)){
            return ucfirst($value);
        }
    }

    public function setAnswerAttribute($value)
    {
        if(!empty($value)){
            $this->attributes['answer'] =  strtolower($value);
        }

    }
}
