<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WfhApplicationDate extends Model
{
    use HasFactory;
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'wfh_application_id',
        'date'
    ];

    public function getDateAttribute($value)
    {
        $date = new Carbon($value);
        return $date->format('d-m-Y');
    }

    public function setDateAttribute($value)
    {
        $date = new Carbon($value);
        $this->attributes['date'] =  $date->format('Y-m-d');
    }

}
