<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Console\Application;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;


class User extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens, SoftDeletes;

    const STATUS = [
        '10' => 'active',
        '20' => 'inactive'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'preferred_name',
        'first_name',
        'last_name',
        'designation',
        'email',
        'password',
        'department_id',
        'office_location_id',
        'picture',
        'joining_date',
        'leaving_date',
        'gender_pronoun',
        'personal_email'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function getStatusAttribute($value)
    {
        if(!empty($value)){
            return self::STATUS[$value];
        }
    }
    public function setStatusAttribute($value)
    {
        if(!empty($value)){
            $this->attributes['status'] =  array_flip(self::STATUS)[strtolower($value)];
        }else{
            $this->attributes['status'] = null;
        }
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id')->orderBy('sort_no');
    }
    public function getFullNameAttribute()
    {
        return ucfirst($this->first_name) . ' ' . ucfirst($this->last_name);
    }
    public function locations()
    {
        return $this->hasMany(WfhLocation::class);
    }
    public function approvedLocations()
    {
        return $this->hasMany(WfhLocation::class)->where('status', array_flip(WfhLocation::STATUS)['Passed']);
    }
    public function applications()
    {
        return $this->hasMany(WfhApplication::class);
    }
    public function isManager()
    {
        return $this->hasOne(Manager::class,'user_id','id');
    }

    public function managerUser()
    {
        return $this->hasOne(ManagerUser::class);
    }
    public function wfhTeamUserAllocation()
    {
        return $this->hasOne(WfhTeamUserAllocation::class,'user_id','id');
    }
    public function userWfhTeamWeekAllocation()
    {
         return $this->hasManyThrough(
            WfhTeamWeekAllocation::class,
            WfhTeamUserAllocation::class,
            'user_id',
            'wfh_team_id',
            'id',
            'wfh_team_id'
         );
    }
    public function staffs()
    {
        return $this->hasManyThrough(
            ManagerUser::class,
            Manager::class,
            'user_id',
            'manager_id',
            'id',
            'id'
        );
    }
    public function officeLocation()
    {
        return $this->belongsTo(OfficeLocation::class);
    }

    public function getPictureAttribute($value)
    {
        if(!empty($value)){
            return url('storage/'.$value);
        }
    }

    public function getLeavingDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            return  $date->format('d-m-Y');
        }
    }
    public function setLeavingDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            $this->attributes['leaving_Date'] =  $date->format('Y-m-d');
        }else{
            $this->attributes['leaving_Date'] = null;
        }
    }
    public function getJoiningDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            return  $date->format('d-m-Y');
        }
    }
    public function setJoiningDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            $this->attributes['joining_Date'] =  $date->format('Y-m-d');
        }else{
            $this->attributes['joining_Date'] = null;
        }
    }

    public function userLogs(){
        return $this->hasMany(UserLog::class,'user_id','id');
    }
    public function latestUserLog(){
        return $this->hasOne(UserLog::class)->latestOfMany();
    }

    /**
     * event handlings
     */
    protected static function booted()
    {
        $role = Role::Default()->first();
        if ($role) {
            static::created(function ($user) use ($role) {
                $roles = $user->roles()->sync($role->id);
            });
        }

        static::deleted(function ($user)  {
            /** Team Users */
            ManagerUser::where('user_id',$user->id)->delete();
            /** User Allocation */
            WfhTeamUserAllocation::where('user_id', $user->id)->delete();
        });

    }
}
