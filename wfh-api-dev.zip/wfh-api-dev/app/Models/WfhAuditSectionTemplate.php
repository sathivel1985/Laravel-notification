<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WfhAuditSectionTemplate extends Model
{
    use HasFactory,SoftDeletes;
    const FORMAT = [
        'text',
        'question',
        'schedule'
    ];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable =  [
        'name',
        'icon',
        'content',
        'format',
        'description',
        'sort_no'
    ];

}
