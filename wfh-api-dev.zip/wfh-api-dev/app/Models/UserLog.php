<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserLog extends Model
{
    use HasFactory, SoftDeletes;

    const TYPE = [
        10 => 'joining',
        20 => 'leaving'
    ];

    const STATUS = [
        10 => 'pending',
        20 => 'approved',
        30 => 'rejected',
        40 => 'withdrawn'
    ];

    protected $fillable = [
        'user_id',
        'requestor_id',
        'approver_id',
        'type',
        'type_date',
        'status',
        'status_date'
    ];

    public function getTypeAttribute($value)
    {
        if(!empty($value)){
            return self::TYPE[$value];
        }
    }

    public function setTypeAttribute($value)
    {
        if(!empty($value)){

            $this->attributes['type'] =  array_flip(self::TYPE)[strtolower($value)];
        }

    }

    public function getTypeDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            return  $date->format('d-m-Y');
        }
    }

    public function setTypeDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            $this->attributes['type_date'] =  $date->format('Y-m-d');
        }else{
            $this->attributes['type_date'] = null;
        }

    }

    public function getStatusAttribute($value)
    {
        if(!empty($value)){
            return self::STATUS[$value];
        }
    }

    public function setStatusAttribute($value)
    {
        if(!empty($value)){

            $this->attributes['status'] =  array_flip(self::STATUS)[strtolower($value)];
        }
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function requestor()
    {
        return $this->belongsTo(User::class,'requestor_id','id');
    }

    public function approver()
    {
        return $this->belongsTo(User::class,'approver_id','id');
    }

    /**
     * Scope a query to only include pending user logs.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopePending($query)
    {
        return $query->where('status', array_flip(self::STATUS)['pending']);
    }
     /**
     * Scope a query to only include pending user logs.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeApproved($query)
    {
        return $query->where('status', array_flip(self::STATUS)['approved']);
    }
     /**
     * Scope a query to only include pending user logs.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeRejected($query)
    {
        return $query->where('status', array_flip(self::STATUS)['rejected']);
    }

}
