<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WfhApplication extends Model
{
    use HasFactory, SoftDeletes;

    const STATUS = [
        '10'=>'PENDING',
        '20'=>'APPROVED',
        '30'=>'REJECTED',
        '40'=>'Withdrawn'
    ];

    const APPLICATIONTYPE = [
        'PERMANENT' => 'Permanent Work-From-Home',
        'RECURRING' => 'Recurring day(s)',
        'SPECIFIC_DAY' => 'Specific date(s)',
    ];
    const RECURRINGDAYS = [
        '1' => 'Monday',
        '2' => 'Tuesday',
        '3' => 'Wednesday',
        '4' => 'Thursdays',
        '5' => 'Friday',
        '6' => 'Saturday',
        '7' => 'Sunday'
    ];

    protected $casts = [
		'recurring_days' => 'json' // save recurring_days as a json column,
 	];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'type',
        'state',
        'start_date',
        'end_date',
        'recurring_days',
        'wfh_location_id',
        'location_status',
        'user_id',
        'wfh_application_reason_id',
        'status',
        'policy_builder_id',
        'co_working_space_id',
        'approver_id',
        'reason_other'
    ];

    /**
     * Return list of type codes and labels

     * @return array
     */
    public static function listTypes()
    {
        $list = [];
        foreach(self::APPLICATIONTYPE AS $key => $value)
        {
            $list[] = [
                'id'   => $key,
                'name' => $value
            ];
        }
        return $list;
    }
    /**
     * Return list of days codes and labels

     * @return array
     */
    public static function listDays()
    {
        $list = [];
        foreach(self::RECURRINGDAYS AS $key => $value)
        {
            $list[] = [
                'id'   => $key,
                'name' => $value
            ];
        }
        return $list;
    }

    /**
     * Return list of status codes and labels

     * @return array
     */
    public static function listStatus()
    {
        $list = [];
        foreach(self::STATUS AS $key => $value)
        {
            $list[] = [
                'id'   => $key,
                'name' => $value
            ];
        }
        return $list;
    }

    public static function isPermanant($type = null)
    {
        if(!empty($type)){
            return $type == 'PERMANENT';
        }
       // return $this->type == array_flip(self::APPLICATIONTYPE)['PERMANENT'];
    }
    public static function isRecurring($type = null)
    {
        if(!empty($type)){
            return $type == 'RECURRING';
        }
       // return $this->type == array_flip(self::APPLICATIONTYPE)['RECURRING'];
    }
    public static function isSpecificDay($type = null)
    {
        if(!empty($type)){
            return $type == 'SPECIFIC_DAY';
        }
        //return $this->type == array_flip(self::APPLICATIONTYPE)['SPECIFIC_DAY'];
    }

    /**
     * Get the Application status label
     *
     * @param  string  $value
     * @return string
     */
    public function getStatusAttribute($value)
    {
        return !empty($value) ? self::STATUS[$value]: null;
    }


    public function getStartDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            return $date->format('d-m-Y');
        }
    }

    public function setStartDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            $this->attributes['start_date'] =  $date->format('Y-m-d');
        }

    }

    public function getEndDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            return $date->format('d-m-Y');
        }
    }

    public function getRecurringDaysAttribute($daysJson)
    {   $dayName = [];
        if(!empty($daysJson)){
            $array = json_decode($daysJson);
            foreach($array AS $dayKey){
                $dayName[] =  self::RECURRINGDAYS[$dayKey];
            }
        }
        return $dayName;
    }

    public function getTypeAttribute($typeKey)
    {
        return self::APPLICATIONTYPE[$typeKey];
    }

    public function setEndDateAttribute($value)
    {
        if(!empty($value)){
            $date = new Carbon($value);
            $this->attributes['end_date'] =  $date->format('Y-m-d');
        }
    }

    public function dates()
    {
        return $this->hasMany(WfhApplicationDate::class);
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function approver() {
        return $this->belongsTo(User::class,'approver_id','id');
    }

    public function location(){
        return $this->belongsTo(WfhLocation::class,'wfh_location_id','id');
    }

    public function reason(){
        return $this->belongsTo(WfhApplicationReason::class,'wfh_application_reason_id','id');
    }

    public function coWorkingSpace()
    {
        return $this->belongsTo(CoWorkingSpace::class,'co_working_space_id','id');
    }

}
