<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WfhLocation extends Model
{
    use HasFactory, SoftDeletes;

    const STATUS = [
        '10' => 'Passed',
        '20' => 'Did-Not-Pass',
        '30' => 'Overridden',
        '40' => 'Draft'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'address',
        'distance',
        'status',
        'user_location_evaluation_id'
    ];

     /**
     * Return list of status codes and labels

     * @return array
     */
    public static function listStatus()
    {
        $list = [];
        foreach(self::STATUS AS $key => $value)
        {
            $list[] = [
                'id'   => $key,
                'name' => str_replace('-',' ',$value)
            ];
        }
        return $list;
    }

    /**
     * Get the location user
     *
     * @param  null
     * @return User @object
     */

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the location evaluions list
     *
     * @param  null
     * @return UserLocationEvaluation @object
     */

    public function evaluations()
    {
        return $this->hasMany(UserLocationEvaluation::class,'wfh_location_id','id');
    }

    /**
     * Get the locaton status label
     *
     * @param  string  $value
     * @return string
     */
    public function getStatusAttribute($value)
    {
        if(!empty($value)) {
            return !empty(self::STATUS[$value]) ?  str_replace('-',' ',self::STATUS[$value]): null;
        }
        return null;
    }
}
