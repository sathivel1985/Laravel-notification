<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use phpDocumentor\Reflection\Types\Self_;

class Manager extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'department_id'
    ];
    /**
     * List of Staff who is reporting to this manager
     */
    public function staffs()
    {
        return $this->hasMany(ManagerUser::class);
    }
    /**
     * Manger details
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    /**
     * Manager staff applications
     */
    public function applications()
    {
        return $this->hasManyThrough(
            WfhApplication::class,
            ManagerUser::class,
            'manager_id',
            'user_id',
            'id',
            'id'
        );
    }

    public function department()
    {
        return $this->belongsTo(Department::class,'department_id','id');
    }
      /**
     * event handlings
     */
    protected static function booted()
    {
        static::created(function ($manager)  {
            if (!empty($manager->user_id)) {
                self::addUpdateManagerRole($manager);
            }
        });
        static::updated(function ($manager)  {
            if (!empty($manager->user_id)) {
                self::addUpdateManagerRole($manager);
            }
        });
    }
    public static function addUpdateManagerRole($manager){
        $roles = $manager->user->roles();
        $roleNames = $roles->pluck('name')->all();
        $roleIds = $roles->pluck('roles.id')->all();
        if (!in_array('manager', array_map('strtolower', $roleNames))) {
            self::managerRoles($manager, $roleIds);
        }
    }
    public static function managerRoles(Self $manager, $roleIds = [])
    {
        $role = Role::where('name','manager')->first();
        if(!$role) {
            $role = Role::create(['name'=>'manager']);
        }
        array_push($roleIds,$role->id );
        $manager->user->roles()->sync($roleIds);
    }
}
