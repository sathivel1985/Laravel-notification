<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserLocationEvaluation extends Model
{
    use HasFactory, SoftDeletes;
      /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'wfh_location_id',
        'user_id',
        'status'
    ];

    public function location()
    {
        return $this->belongsTo(WfhLocation::class,'wfh_location_id','id');
    }

}
