<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use Illuminate\Http\Request;
// use Illuminate\Foundation\Validation\ValidatesRequests;
use Crypt;
use Google2FA;

class Google2FAController extends Controller
{
    // use ValidatesRequests;
    /**
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function enableTwoFactor(Request $request)
    {
        $request->validate(
            ['secretKey' => 'required']
        );
        //get secret key secret
        $secret = $request->secretKey;
        //get user
        $user = $request->user();
        $user->google2fa_secret = $secret;
        $user->save();

    
        $user = new UserResource($user);
        return response()->json($user, 200 );
    }

    public function getTwoFactor(Request $request)
    {
        //generate new secret
        // $secret = $this->generateSecret();
        $secret = Google2FA::generateSecretKey();

        //get user
        $user = $request->user();

        //generate image for QR barcode
        $imageDataUri = Google2FA::getQRCodeInline(
            $request->getHttpHost(),
            $user->email,
            $secret,
            200
        );
        return response()->json([
            'image' => $imageDataUri,
            'secret' => $secret
        ]);
    }

    /**
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function disableTwoFactor(Request $request)
    {
        $user = $request->user();

        //make secret column blank
        $user->google2fa_secret = null;
        $user->save();

        return response()->json(['message' => 'disabled'], 200);
    }

    /**
     * Generate a secret key in Base32 format
     *
     * @return string
     */
    private function generateSecret()
    {
        $randomBytes = random_bytes(10);

        return Base32::encodeUpper($randomBytes);
    }
}
