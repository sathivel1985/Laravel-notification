<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\AuthLoginRequest;
use App\Http\Requests\Auth\AuthRegisterRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use Illuminate\Support\Facades\Password;
use Google2FA;
use Crypt;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public $userService;
    public function __construct( UserService $userService ) {

        $this->userService  = $userService;
    }
    // public function register(AuthRegisterRequest $request) {
    //     $validated = $request->validated();
    //     $validated['password'] = Hash::make($validated['password']);
    //     $validated['name'] = $validated['fullName'];
    //     $user = User::create($validated);
    //     $accessToken = $user->createToken('authToken')->accessToken;
    //     return response(['user' => $user, 'token' => $accessToken->accessToken]);
    // }

    public function login(AuthLoginRequest $request)
    {
        $validated = $request->validated();

        if (!auth()->attempt($validated)) {
            return response(['message' => 'This User does not exist, check your details'], 400);
        }

        if (auth()->user()->status != 'active') {
            return response(['message' => 'Your account is inactive'], 400);
        }

        $accessToken = auth()->user()->createToken('authToken');
        $user =auth()->user()->load(['roles','isManager.user','officeLocation.country']);
    //    return new UserResource($user, $accessToken->accessToken);
       $userResource = new UserResource($user, $accessToken->accessToken);
       return $this->userService->userResponse($userResource,$user->id);
    }
    public function logout(Request $request)
    {
        if (Auth::check()) {
            Auth::user()->token()->revoke();
            return response()->json(['success' => 'logout_success'], 200);
        } else {
            return response()->json(['error' => 'api.something_went_wrong'], 500);
        }
    }

    public function requestPassword(Request $request)
    {
        $request->validate(['email' => 'required|email']);
        $status = Password::sendResetLink(
            $request->only('email')
        );
        $status === Password::RESET_LINK_SENT;
        return response()->json($status);
    }

    public function verify2FA(Request $request)
    {
        $request->validate(
            ['secretKey' => 'required']
        );
        $user = Auth::user();
        $is_verified = Google2FA::verifyKey($user->google2fa_secret, $request->secretKey);
        if($is_verified) {
            return response()->json(new UserResource($user), 200 );
        }
        return response()->json(['is_verified' => $is_verified, 'message' => 'Invalid token'], 400);
    }

}
