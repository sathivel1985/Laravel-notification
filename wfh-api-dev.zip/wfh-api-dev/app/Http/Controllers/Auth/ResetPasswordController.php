<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Validation\Rules\Password;

class ResetPasswordController extends Controller
{
    public function resetPassword(Request $request)
    {
        $data = $request->all();
        $data['password_confirmation'] = $data['confirmPassword'];
        unset($data['confirmPassword']);
        $validator = Validator::make($data, [
            'email' => 'required|email',
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);
        $validator->validate();
        return $this->validateToken($request)->count() > 0 ? $this->changePassword($request) : $this->noToken();
    }

    private function validateToken($request)
    {
        return DB::table('password_resets')->where([
            'email' => $request->email,
            'token' => $request->token
        ]);
    }

    private function noToken()
    {
        return response()->json([
            'error' => 'Email or token does not exist.'
        ], Response::HTTP_UNPROCESSABLE_ENTITY);
    }

    private function changePassword($request)
    {
        $user = User::whereEmail($request->email)->first();
        $user->update([
            'password' => bcrypt($request->password)
        ]);
        $this->validateToken($request)->delete();
        return response()->json([
            'data' => 'Password changed successfully.'
        ], Response::HTTP_CREATED);
    }  
}
