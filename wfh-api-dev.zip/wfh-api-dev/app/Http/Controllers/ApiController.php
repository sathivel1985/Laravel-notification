<?php

namespace App\Http\Controllers;

use App\Traits\ApiResponseTrait;
use Illuminate\Http\Request;

class ApiController extends Controller
{
    use ApiResponseTrait;
    public function __construct(){
        $this->middleware('auth:api');
    }
}
