<?php

namespace App\Http\Controllers\Api\Reports;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Models\PolicyBuilder;
use App\Services\ApplicationService;
use App\Services\PolicyBuilderService;
use App\Services\UserService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WFHReport extends ApiController
{

    public $applicationService, $userService, $policyBuilderService;

    public function __construct(ApplicationService $applicationService, UserService $userService, PolicyBuilderService $policyBuilderService)
    {
        parent::__construct();
        $this->applicationService = $applicationService;
        $this->userService = $userService;
        $this->policyBuilderService = $policyBuilderService;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function todayWfhAndWfoReport(Request $request)
    {
        if(empty($request->office_location_id)){
            return null;
        }

        $policyBuilder   = PolicyBuilder::getLatestPolicyBuilderByOfficeLocation($request->office_location_id);
        $today           = Carbon::now()->toDateString();
        $wfhApprovedApplication = $this->applicationService->approvedApplicationListByStateAndDate('wfh',$today);
        if ($policyBuilder && strtolower($policyBuilder->perm_state) == 'wfh') {

            $userAllocations        = $this->policyBuilderService->userAllocationByPolicyBuilder($policyBuilder, $today);
            $wfoApprovedApplication = $this->applicationService->approvedApplicationListByStateAndDate('wfo',$today);
            $exceptEssentialUser    = $userAllocations->filter(function($item) {
                                        return $item->is_essential == 0;
                                    })->count();
            $essentialUsers         = $userAllocations->filter(function($item) {
                                        return $item->is_essential == 1;
                                    })->count();
            $data = [
                "wfh" => ($exceptEssentialUser + $wfhApprovedApplication) - $wfoApprovedApplication ,
                "wfo" => ($wfoApprovedApplication) + ($essentialUsers - $wfhApprovedApplication )
            ];
            return $this->customResponse($data);
        }
        $totalUser = $this->userService->totalUserByLocation($request->office_location_id);
        $data = [
            "wfh" => $wfhApprovedApplication,
            "wfo" => ($totalUser - $wfhApprovedApplication )
        ];

        return $this->customResponse($data);
    }

    public function schedulingReport(Request $request)
    {
        $department  =  '';
        if((!empty($request->department_id))) {
            $in = $this->createInClause($request->department_id);
            $department = " AND DEPARTMENT.id IN ($in) ";
        }
        $officeLocation  =  '';
        $holidayOfficeLocation = '';
        if ((!empty($request->office_location_id))) {
            $in = $this->createInClause($request->office_location_id);
            $officeLocation = " AND users.office_location_id IN ($in) ";
            $holidayOfficeLocation = " AND holiday.office_location_id IN ($in) ";
        }

        $userSelection  =  '';
        if ((!empty($request->user_id))) {
            $in = $this->createInClause($request->user_id);
            $userSelection = " AND users.id IN ($in) ";
        }

        $date = "";

        if (!empty($request->start_date) AND !empty($request->end_date)) {
            $date = " AND date(cal_date.date) >='".date('Y-m-d',strtotime($request->start_date))."'".
                          " AND date(cal_date.date) <='".date('Y-m-d',strtotime($request->end_date))."'";
        }

        $calenderSql = "select distinct cal_date.date,hol_date.date AS holiday_date,cal_date.week_number from fiscal_calendars  as cal_date
                        LEFT JOIN holiday_dates AS hol_date ON hol_date.date=cal_date.date
                        LEFT JOIN holidays AS holiday ON holiday.id=hol_date.holiday_id
                        where 1=1 {$date} {$holidayOfficeLocation}";

        $calendarDates = DB::select($calenderSql);
        if(count($calendarDates) > 32) {
            return $this->customResponse([
                'headers' => null,
                'names' => null,
                'todayReport' => null,
                'message' => "Reporting period should not be more than 31 days"
            ]);
        }

        $sql = "
            (SELECT users.id as user_id, concat(users.first_name,' ',users.last_name) as name,
             cal_date.date, cal_date.week_number as cal_week_number,
             week_al.week_number as week_al_week_number, NULL as state
            FROM users as users
            LEFT JOIN wfh_team_user_allocations as user_al ON user_al.user_id = users.id  AND user_al.deleted_at IS NULL
            LEFT JOIN  wfh_teams as teams ON teams.id = user_al.wfh_team_id AND teams.deleted_at IS NULL
            LEFT JOIN wfh_team_week_allocations as week_al ON week_al.wfh_team_id = teams.id  AND week_al.deleted_at IS NULL
            LEFT JOIN fiscal_calendars as cal_date ON cal_date.date = week_al.date {$date}
            LEFT JOIN manager_users AS MANAGER_USER ON MANAGER_USER.user_id = users.id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN managers AS MANAGERS ON MANAGERS.id = MANAGER_USER.manager_id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN departments AS DEPARTMENT ON DEPARTMENT.id = MANAGERS.department_id AND DEPARTMENT.deleted_at IS NULL
            WHERE users.status = 10  AND users.deleted_at IS NULL
            {$officeLocation}
            {$department}
            {$userSelection}
            ORDER BY users.first_name  ASC )
            UNION
            ( SELECT users.id as user_id, concat(users.first_name,' ',users.last_name) as name,
             cal_date.date, cal_date.week_number as cal_week_number,
              week_al.week_number as week_al_week_number, NULL as state
                FROM users as users
            LEFT JOIN wfh_team_user_allocations as user_al ON user_al.user_id = users.id  AND user_al.deleted_at IS NULL
            LEFT JOIN  wfh_teams as teams ON teams.id = user_al.wfh_team_id AND teams.deleted_at IS NULL
            LEFT JOIN wfh_team_week_allocations as week_al ON week_al.wfh_team_id = teams.id  AND week_al.deleted_at IS NULL
            LEFT JOIN fiscal_calendars as cal_date ON cal_date.year = week_al.year AND  cal_date.week_number = week_al.week_number  {$date}
            LEFT JOIN manager_users AS MANAGER_USER ON MANAGER_USER.user_id = users.id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN managers AS MANAGERS ON MANAGERS.id = MANAGER_USER.manager_id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN departments AS DEPARTMENT ON DEPARTMENT.id = MANAGERS.department_id AND DEPARTMENT.deleted_at IS NULL
            WHERE users.status = 10 AND users.deleted_at IS NULL
            {$officeLocation}
            {$department}
            {$userSelection}
            ORDER BY users.first_name  ASC )

            UNION
            ( SELECT users.id as user_id, concat(users.first_name,' ',users.last_name) as name,
             cal_date.date, NULL as  cal_week_number,
              NULL  week_al_week_number,
              apl.state
                FROM users as users
            INNER JOIN wfh_applications as apl ON apl.user_id = users.id AND apl.status = 20
            INNER JOIN wfh_application_dates AS cal_date ON cal_date.wfh_application_id = apl.id {$date}

            LEFT JOIN manager_users AS MANAGER_USER ON MANAGER_USER.user_id = users.id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN managers AS MANAGERS ON MANAGERS.id = MANAGER_USER.manager_id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN departments AS DEPARTMENT ON DEPARTMENT.id = MANAGERS.department_id AND DEPARTMENT.deleted_at IS NULL
            WHERE users.status = 10 AND users.deleted_at IS NULL
            {$officeLocation}
            {$department}
            {$userSelection}
            ORDER BY users.first_name ASC, cal_date.id ASC)
        ";
        // return response()->json($sql, 200);
        $schedules = DB::select($sql);

        $names = [];
        if ($schedules) {

            foreach ($schedules AS $schedule) {
                $scheduleDateFormat =  date('d-m-Y',strtotime($schedule->date));
                if (!isset($names[$schedule->name])) {
                    $names[$schedule->name] = [];
                    $states[$schedule->name] = [];
                }
                if($schedule->date) {
                    $names[$schedule->name][$scheduleDateFormat] = $scheduleDateFormat;
                    if($schedule->state){
                        $states[$schedule->name][$scheduleDateFormat] = $schedule->state;
                    }

                }
            }
        }

        $formatName = [];
        $formatDates = [];
        if ($calendarDates) {
            foreach ( $calendarDates as $calendarDate ) {
                $calDateFormat = date('d-m-Y',strtotime($calendarDate->date));
                foreach ($names as $name => $dates) {
                    if (!isset($formatName[$name])) {
                        $formatName[$name]['name'] = $name;
                    }
                    if (in_array($calDateFormat, $dates)) {
                        $formatName[$name][$calDateFormat] = 'WFO';
                    } else {
                        $formatName[$name][$calDateFormat] = "WFH";
                    }
                    if(isset($states[$name][$calDateFormat])){
                        $formatName[$name][$calDateFormat] = strtoupper($states[$name][$calDateFormat]);
                    }
                }
                $formatDates[]  =  [
                    'date' => $calDateFormat,
                    'week' => $calendarDate->week_number,
                    'holiday' => !empty($calendarDate->holiday_date) ? true:false,
                ];
            }
        }
        $data = [
            'headers' => $formatDates,
            'names'   => array_values($formatName),
        ];

        return $this->customResponse($data);
    }

    private function createInClause($arr)
    {
        return '\'' . implode('\', \'', $arr) . '\'';
    }
    /*private function todayReport($officeLocation, $department ) {
        $today = Carbon::now()->toDateString();
        $date = " AND date(cal_date.date) ='". $today."'";
        $sql = "
            (SELECT users.id as user_id, concat(users.first_name,' ',users.last_name) as name,
             cal_date.date, cal_date.week_number as cal_week_number,
             week_al.week_number as week_al_week_number, NULL as state
            FROM users as users
            LEFT JOIN wfh_team_user_allocations as user_al ON user_al.user_id = users.id  AND user_al.deleted_at IS NULL
            LEFT JOIN  wfh_teams as teams ON teams.id = user_al.wfh_team_id AND teams.deleted_at IS NULL
            LEFT JOIN wfh_team_week_allocations as week_al ON week_al.wfh_team_id = teams.id  AND week_al.deleted_at IS NULL
            LEFT JOIN fiscal_calendars as cal_date ON cal_date.date = week_al.date {$date}
            LEFT JOIN manager_users AS MANAGER_USER ON MANAGER_USER.user_id = users.id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN managers AS MANAGERS ON MANAGERS.id = MANAGER_USER.manager_id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN departments AS DEPARTMENT ON DEPARTMENT.id = MANAGERS.department_id AND DEPARTMENT.deleted_at IS NULL
            WHERE users.status = 10  AND users.deleted_at IS NULL
            {$officeLocation}
            {$department}
            ORDER BY users.first_name  ASC )
            UNION
            ( SELECT users.id as user_id, concat(users.first_name,' ',users.last_name) as name, cal_date.date,
             cal_date.week_number as cal_week_number, week_al.week_number as week_al_week_number, NULL as state
                FROM users as users
            LEFT JOIN wfh_team_user_allocations as user_al ON user_al.user_id = users.id  AND user_al.deleted_at IS NULL
            LEFT JOIN  wfh_teams as teams ON teams.id = user_al.wfh_team_id AND teams.deleted_at IS NULL
            LEFT JOIN wfh_team_week_allocations as week_al ON week_al.wfh_team_id = teams.id  AND week_al.deleted_at IS NULL
            LEFT JOIN fiscal_calendars as cal_date ON cal_date.year = week_al.year AND  cal_date.week_number = week_al.week_number  {$date}
            LEFT JOIN manager_users AS MANAGER_USER ON MANAGER_USER.user_id = users.id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN managers AS MANAGERS ON MANAGERS.id = MANAGER_USER.manager_id AND MANAGER_USER.deleted_at IS NULL
            LEFT JOIN departments AS DEPARTMENT ON DEPARTMENT.id = MANAGERS.department_id AND DEPARTMENT.deleted_at IS NULL
            WHERE users.status = 10 AND users.deleted_at IS NULL
            {$officeLocation}
            {$department}
            ORDER BY users.first_name  ASC )

            UNION
            ( SELECT users.id as user_id, concat(users.first_name,' ',users.last_name) as name,
             cal_date.date, cal_date.week_number as cal_week_number, week_al.week_number as week_al_week_number,
              apl.state
                FROM users as users
            INNER JOIN wfh_applications as apl ON apl.user_id = users.id AND apl.status = 20
            INNER JOIN wfh_application_dates AS cal_date ON cal_date.wfh_application_id = apl.id {$date}
            INNER JOIN manager_users AS MANAGER_USER ON MANAGER_USER.user_id = users.id AND MANAGER_USER.deleted_at IS NULL
            INNER JOIN managers AS MANAGERS ON MANAGERS.id = MANAGER_USER.manager_id AND MANAGER_USER.deleted_at IS NULL
            INNER JOIN departments AS DEPARTMENT ON DEPARTMENT.id = MANAGERS.department_id AND DEPARTMENT.deleted_at IS NULL
            WHERE users.status = 10 AND users.deleted_at IS NULL
            {$officeLocation}
            {$department}
            ORDER BY users.first_name  ASC )

        ";
        return response()->json($sql, 200 );
        $schedules = DB::select($sql);
        $names = [];
        if ($schedules) {
            foreach ($schedules as $schedule) {
                $scheduleDateFormat =  date('d-m-Y', strtotime($schedule->date));
                if (!isset($names[$schedule->name])) {
                    $names[$schedule->name] = [];
                }
                if ($schedule->date) {
                    $names[$schedule->name][$scheduleDateFormat] = $scheduleDateFormat;
                }
            }
        }
        $today = date('d-m-Y', strtotime($today));
        $data = [
            'wfh' => 0,
            'wfo' => 0
        ];
        foreach ($names as $name => $dates) {
            if (!isset($formatName[$name])) {
                $formatName[$name]['name'] = $name;
            }
            if (in_array($today, $dates)) {
                ++$data['wfh'];
            } else {
                ++$data['wfo'];
            }
        }
        return $data;

    }*/


}
