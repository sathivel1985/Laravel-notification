<?php

namespace App\Http\Controllers\Api\Reports;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Models\WfhAuditSection;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class AuditSectionQuestionAnswerReport extends ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {

        $country  =  (!empty($request->country_id) ) ?  " AND COUNTRY.id=".$request->country_id:'';
        $department  =  '';
        if((!empty($request->department_id))) {
            $in = $this->createInClause($request->department_id);
            $department = " AND DEPARTMENT.id IN ($in) ";
        }
        $officeLocation  =  '';
        if ((!empty($request->office_location_id))) {
            $in = $this->createInClause($request->office_location_id);
            $officeLocation = " AND LOCATION.id IN ($in) ";
        }
        $userSelection  =  '';
        if ((!empty($request->user_id))) {
            $in = $this->createInClause($request->user_id);
            $userSelection = " AND USERS.id IN ($in) ";
        }
        $answerDate = "";
        if (!empty($request->start_date) AND !empty($request->end_date)) {
            $answerDate = " AND date(ANSWERS.created_at) >='".date('Y-m-d',strtotime($request->start_date))."'".
                          " AND date(ANSWERS.created_at) <='".date('Y-m-d',strtotime($request->end_date))."'";
        }
        $sql = "
            SELECT  QUESTIONS.id, QUESTIONS.title as question_title, SECTIONS.name as section , ANSWERS.answer,  IF(ANSWERS.answer IS NULL , 0 , count(1)  )   AS total
            FROM wfh_audit_section_questions  as QUESTIONS
            LEFT JOIN wfh_audit_sections AS SECTIONS ON SECTIONS.id = QUESTIONS.wfh_audit_section_id
            LEFT JOIN wfh_audit_section_answers AS ANSWERS ON ANSWERS.wfh_audit_section_question_id = QUESTIONS.id
            LEFT JOIN users AS USERS ON USERS.id = ANSWERS.user_id
            LEFT JOIN manager_users AS MANAGER_USER ON MANAGER_USER.user_id = USERS.id
            LEFT JOIN managers AS MANAGERS ON MANAGERS.id = MANAGER_USER.manager_id
            LEFT JOIN departments AS DEPARTMENT ON DEPARTMENT.id = MANAGERS.department_id
            LEFT JOIN office_locations as LOCATION  ON LOCATION.id = USERS.office_location_id
            LEFT JOIN countries AS COUNTRY  ON COUNTRY.id =  LOCATION.country_id
            WHERE SECTIONS.format = 'question'
            AND SECTIONS.deleted_at IS NULL
            AND QUESTIONS.deleted_at IS NULL
            AND ANSWERS.deleted_at IS NULL
            AND USERS.deleted_at IS NULL
            AND MANAGERS.deleted_at IS NULL
            AND DEPARTMENT.deleted_at IS NULL
            AND LOCATION.deleted_at IS NULL
            {$country}
            {$officeLocation}
            {$department}
            {$answerDate}
            {$userSelection}
            GROUP BY QUESTIONS.id,QUESTIONS.title, SECTIONS.id, SECTIONS.name, ANSWERS.answer ORDER BY SECTIONS.sort_no, QUESTIONS.id, QUESTIONS.title";

        $sections =DB::select($sql);
        $sections = collect($sections);
        $yes = [];
        $no = [];
        $categories = [];
        $data = [];
        if ($sections) {

            $reports = [];
            foreach ($sections as $section) {
                if(!isset($reports[$section->section][$section->question_title]['yes'])) {
                    $reports[$section->section][$section->question_title]['yes'] = 0 ;
                }
                if (!isset($reports[$section->section][$section->question_title]['no'])) {
                    $reports[$section->section][$section->question_title]['no'] = 0;
                }
                if($section->answer) {
                    $reports[$section->section][$section->question_title][$section->answer] = $section->total;
                }

            }
            //return response()->json($reports);
            foreach ($reports as $section => $report_section) {
                $data[$section] = [
                    'section' => $section,
                    'question' => []
                ];
                foreach ($report_section as $title => $report) {
                    $data[$section]['question'][$title] = [
                        'title' => $title,
                        'data' => []
                    ];
                    $sum = array_sum(array_values($report));
                    foreach ($report as $index => $value) {
                        $data[$section]['question'][$title]['data'][] = [
                            'name' => strtoupper($index),
                            'y' => ($value > 0 ) ? ($value / $sum ) * 100 : 0
                        ];
                    }
                }
            }
            // foreach($reports as $section => $report) {
            //     array_push($categories, $section);
            //     foreach($report as $index => $value ) {
            //         if (strtolower($index) == 'yes') {
            //             array_push($yes, $value);
            //         }
            //         if (strtolower($index) == 'no') {
            //             array_push($no, $value);
            //         }
            //     }
            // }
            // $data = [
            //     'categories' => $categories,
            //     'dataSet' => [
            //         [
            //             'name' => 'Yes',
            //             'data' => $yes,
            //         ],
            //         [
            //             'name' => 'No',
            //             'data' => $no,
            //         ]
            //     ]
            // ];
            return $this->customResponse(array_values($data));
        }

    }
    private function createInClause($arr)
    {
        return '\'' . implode('\', \'', $arr) . '\'';
    }
}
