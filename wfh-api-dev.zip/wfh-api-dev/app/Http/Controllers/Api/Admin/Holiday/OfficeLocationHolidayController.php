<?php

namespace App\Http\Controllers\Api\Admin\Holiday;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Holiday\HolidayRequest;
use App\Http\Resources\Admin\Holiday\HolidayCollection;
use App\Http\Resources\Admin\Holiday\HolidayResource;
use App\Models\Country;
use App\Models\Holiday;
use App\Models\OfficeLocation;
use App\Services\DateService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OfficeLocationHolidayController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(OfficeLocation $officeLocation)
    {
        $holidays = $officeLocation->holidays()->get();

        return new HolidayCollection($holidays);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(HolidayRequest $request)
    {

        $dateServices = new DateService();
        $error = [];
        foreach($request->office_locations AS $location){

            $locationDates = DB::table('holiday_dates')
            ->join('holidays', 'holidays.id', '=', 'holiday_dates.holiday_id')
            ->select('holiday_dates.date')
            ->where('holidays.office_location_id', $location)
            ->pluck('holiday_dates.date')->toArray();


            $rangeDates = $dateServices->getDatesFromRange($request->start_date,$request->end_date);
            $holidayDates = array_diff($rangeDates,$locationDates);

            if (  count($holidayDates) == count($rangeDates)) {
                $holiday = Holiday::create([
                    'office_location_id' => $location,
                    'start_date'         => $request->start_date,
                    'end_date'           => $request->end_date,
                    'category'           => $request->category,
                    'description'        => $request->description,
                    'user_id'            => $request->user()->id
                ]);

                $insertDate = [];
                foreach($holidayDates AS $date){
                    $insertDate[] = ['date' => $date];
                }
                $holiday->dates()->createMany($insertDate);
            }else{
                $error[$location] = "error";
            }

        }

        $holidays = Holiday::with('officeLocation')->whereIn('office_location_id',  $request->office_locations)->get();
        return new HolidayCollection($holidays);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Holiday $holiday, OfficeLocation $officeLocation)
    {
         return new HolidayResource($holiday);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(HolidayRequest $request, Holiday $holiday, OfficeLocation $officeLocation)
    {

        $holiday->fill($request->all());
        if($holiday->isClean()){
            return $this->error(['message'=>'Please specify the new value to update']);
        }
        $holiday->save();
        return new HolidayResource($holiday);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( OfficeLocation $officeLocation,Holiday $holiday)
    {
        $holiday->delete();
        return $this->success(['message' => 'deleted successfully']);
    }

    public function listHolidayByCountry(Country $country)
    {
        $officeLocations = $country->officeLocations()->pluck('id')->all();
        $holidays = Holiday::with('officeLocation')->whereIn('office_location_id',  $officeLocations)->get();
        return new HolidayCollection($holidays);
    }
}
