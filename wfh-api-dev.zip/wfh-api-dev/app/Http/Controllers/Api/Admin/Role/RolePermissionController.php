<?php

namespace App\Http\Controllers\Api\Admin\Role;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Role\RolePermissionRequest;
use App\Http\Resources\PermissionResource;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;

class RolePermissionController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Role $role)
    {
        $permissions = $role->permissions()->get();
        return  PermissionResource::collection($permissions);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RolePermissionRequest $request, Role $role)
    {
        $role->permissions()->sync($request->permissions);
        return PermissionResource::collection($role->permissions);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Role $role, Permission $permission)
    {
        $role->permissions()->detach($permission->id);
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
