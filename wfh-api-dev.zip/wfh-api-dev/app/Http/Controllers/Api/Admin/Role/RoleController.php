<?php

namespace App\Http\Controllers\Api\Admin\Role;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Role\RoleRequest;
use App\Http\Resources\RoleResource;
use App\Models\Role;
use Illuminate\Http\Request;

class RoleController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $roles = Role::with(['permissions:id,name,description'])
        ->ExceptDefault()
        ->orderBy('sort_no')
        ->get(['id','name','description']);
        return RoleResource::collection($roles);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RoleRequest $request)
    {
        $role = Role::create($request->all());
        if($request->has('permissions')) {
            if(count($request->permissions)>0){
                $permissions = array_filter($request->permissions);
                $role->permissions()->sync($permissions);
            }
        }
        $role = $role->load('permissions');
        return new RoleResource($role);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Role $role)
    {
        $role = $role->load(['permissions:id,name,description']);
        return new RoleResource($role);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(RoleRequest $request, Role $role)
    {
        $role->fill($request->only(['name', 'description']));
        $role->save();
        if($request->has('permissions') && count($request->permissions)>0) {
            $permissions = array_filter($request->permissions);
            $role->permissions()->sync($permissions);
        }else{
            $role->permissions()->detach();
        }
        $role = $role->load('permissions');
        return new RoleResource($role);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Role $role)
    {
        $role->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
