<?php

namespace App\Http\Controllers\Api\Admin\Department;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Admin\Department\DepartmentRequest;
use App\Http\Resources\Admin\Country\OfficeLocationResource;
use App\Http\Resources\Admin\Department\DepartmentResource;
use App\Http\Resources\UserCollection;
use App\Models\Country;
use App\Models\Department;
use App\Models\Manager;
use App\Models\OfficeLocation;
use App\Models\User;
use Illuminate\Http\Request;

class DepartmentController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $departments = Department::all();
        return DepartmentResource::collection($departments);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DepartmentRequest $request)
    {
        /** Todod : Manager Can I have one department */
        $department = Department::create($request->only(['name','office_location_id']));

        Manager::create([
            'department_id' => $department->id,
            'user_id'       => $request->user_id ?? null
        ]);
        $department = $department->load('manager.user');
        return new DepartmentResource($department);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Department $department)
    {
        return new DepartmentResource($department);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(DepartmentRequest $request, Department $department)
    {
        /** Todod : Manager Can I have one department */
        $department->fill($request->all());
        $department->save();
        if(!empty($request->user_id)){
            $manager = Manager::where('user_id', $request->user_id)->first();
            if( $manager) {
                $manager->user_id  = null;
                $manager->save();
            }
            Manager::updateOrCreate(
                [ 'department_id' => $department->id ],
                [ 'user_id' => $request->user_id ]
            );
        }
        $department = $department->load('manager.user');
        return new DepartmentResource($department);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Department $department)
    {
        $department->manager()->delete();
        $department->delete();
        return $this->success(['message'=>'deleted successfully']);
    }

    public function departmentByCountry(Country $country)
    {
        $officeLocations = OfficeLocation::with(['departments','country'])->where('country_id',$country->id)->get();
        return  OfficeLocationResource::collection($officeLocations);
    }
    public function departmentByOfficeLocation(OfficeLocation $officeLocation)
    {
        $departments = Department::with(['manager.user'])->where('office_location_id',$officeLocation->id)->get();
        return  DepartmentResource::collection($departments);
    }

    public function listOfManagerByOfficeLocation(OfficeLocation $officeLocation)
    {

        $managers = User::whereHas('isManager')->with('isManager.department')
        ->where('office_location_id',$officeLocation->id)
        ->get();

        // $managers =  $managers->map(function($item){
        //     $name = $item->first_name.' '.$item->last_name;
        //     return [
        //         'id'    => $item->id,
        //         'name'  => trim($name),
        //         'departmentId' => $item->is_manager->department->id ?? '',
        //         'departmentName' => $item->is_manager->department->name ?? ''
        //     ];
        // });
      // $managers = User::whereHas('departmentManager')->get();
        return new UserCollection($managers);
    }
}
