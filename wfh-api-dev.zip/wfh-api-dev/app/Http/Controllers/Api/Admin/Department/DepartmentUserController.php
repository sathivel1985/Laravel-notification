<?php

namespace App\Http\Controllers\Api\Admin\Department;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Resources\Admin\Department\DepartmentResource;
use App\Models\Department;
use App\Models\Manager;
use App\Models\ManagerUser;
use Illuminate\Http\Request;

class DepartmentUserController extends ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Department $department)
    {
        $department = $department->load(['departmentUser.user','manager.user']);
        return new DepartmentResource($department);
    }
}
