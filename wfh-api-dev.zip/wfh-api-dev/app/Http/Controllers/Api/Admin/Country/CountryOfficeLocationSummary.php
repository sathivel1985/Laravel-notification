<?php

namespace App\Http\Controllers\Api\Admin\Country;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\Department;
use App\Models\OfficeLocation;

class CountryOfficeLocationSummary extends  ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Country $country)
    {

        $officeLocationId = OfficeLocation::where('country_id',$country->id)->pluck('id')->all();
        if(!$officeLocationId){
            return $this->customResponse("");
        }
        $officeLocationCounts = OfficeLocation::withCount(['users','departments'])->where('country_id',$country->id)
        ->get();
        $officeLocationId = OfficeLocation::where('country_id',$country->id)->pluck('id')->all();
        $departmentCounts = Department::withCount('departmentUser')
        ->with(['departmentUser.user:id,first_name,last_name','manager.user:id,first_name,last_name'])
        ->whereIn('office_location_id', $officeLocationId)->get();

        $departmentGroupByOffice =  $departmentCounts->groupBy(function($item){
           return $item->office_location_id;
        })->toArray();

        $output = $officeLocationCounts->map(function($item) use ($departmentGroupByOffice){
            $customItem = $item;
            if(isset($departmentGroupByOffice[$item->id])){
                $customItem->department= $departmentGroupByOffice[$item->id];


            }
            return $customItem;
        });


        return $this->customResponse($output);
    }
}
