<?php

namespace App\Http\Controllers\Api\Admin\Country;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Admin\Country\OfficeLocationRequest;
use App\Http\Resources\Admin\Country\OfficeLocationResource;
use App\Models\Country;
use App\Models\OfficeLocation;
use Illuminate\Http\Request;

class CountryOfficeLocationController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Country $country)
    {
        $officeLocations = $country->officeLocations()->get();
        return  OfficeLocationResource::collection($officeLocations);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(OfficeLocationRequest $request, Country $country)
    {
        $officeLocation = new OfficeLocation($request->only('name','address'));
        $addedLocation =  $country->officeLocations()->save($officeLocation);
        return new OfficeLocationResource($addedLocation);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Country $country, OfficeLocation $officeLocation)
    {
        $officeLocation = $officeLocation->load('country');
        return new OfficeLocationResource($officeLocation);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(OfficeLocationRequest $request, Country $country,OfficeLocation $officeLocation )
    {
        $officeLocation->fill($request->all());
        if($officeLocation->isClean()) {
           return $this->error(['message'=>'Please specify the new value to update']);
        }
        $officeLocation->save();
        return new OfficeLocationResource($officeLocation);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Country $country,OfficeLocation $officeLocation)
    {
        $officeLocation->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
