<?php

namespace App\Http\Controllers\Api\Admin\Country;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Admin\Country\CountryListRequest;
use App\Http\Resources\Admin\Country\CountryListResource;
use App\Models\CountryList;
use Illuminate\Http\Request;

class CountryListController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $countries = CountryList::all();
        return CountryListResource::collection($countries);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CountryListRequest $request)
    {
        $country = CountryList::create($request->all());
        return new CountryListResource($country);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(CountryList $country_list)
    {
        return new CountryListResource($country_list);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CountryListRequest $request, CountryList $country_list)
    {

        $country_list->fill($request->only(['name','code']));
        if($country_list->isClean()) {
            return $this->error(['message'=>'Please specify the new value to update']);
        }
        $country_list->save();
        return new CountryListResource($country_list);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( CountryList $country_list)
    {
        $country_list->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
