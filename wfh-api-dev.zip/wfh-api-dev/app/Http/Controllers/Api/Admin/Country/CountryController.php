<?php

namespace App\Http\Controllers\Api\Admin\Country;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Admin\Country\CountryRequest;
use App\Http\Resources\Admin\Country\CountryResource;
use App\Models\Country;
use App\Models\OfficeLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CountryController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $countries = Country::with('officeLocations')->get();
        return CountryResource::collection($countries);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CountryRequest $request)
    {
        return DB::transaction(function () use($request){
            $country = Country::create($request->only(['name','entity']));
            $data = [];
            foreach($request->officeLocations AS $location){
                $data[] =  new OfficeLocation([
                    'name'      => $location['name'],
                    'address'   => $location['address']
                ]);
            }

            $country->officeLocations()->saveMany($data);
            $countryLocations = $country->load('officeLocations');
            return new CountryResource($countryLocations);
        });

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Country $country)
    {
        $country = $country->load('officeLocations');
        return new CountryResource($country);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CountryRequest $request, Country $country)
    {
        return DB::transaction(function () use($request, $country){
            $country->fill($request->only(['name','entity']));
            $country->save();
            $data = [];
            foreach($request->officeLocations AS $location){
                OfficeLocation::updateOrCreate(
                   ['id' => $location['id'],'country_id' => $country->id ],
                   ['name' => $location['name'],'address' => $location['address']]
                );
            }
            $countryLocations = $country->load('officeLocations');
            return new CountryResource($countryLocations);
        });

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Country $country)
    {
        $country->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
