<?php

namespace App\Http\Controllers\Api\Admin\Country;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\Country;
use App\Models\OfficeLocation;
use App\Models\User;
use Illuminate\Http\Request;

class CountryuserController extends ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Country $country)
    {
        $officeLocationId = OfficeLocation::where('country_id',$country->id)->pluck('id')->all();
        if(!$officeLocationId){
            return $this->customResponse("");
        }

        $users = User::whereIn('office_location_id', $officeLocationId)->get();
        return UserResource::collection($users);

    }
}
