<?php

namespace App\Http\Controllers\Api\Admin\Manager;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Manager\ManagerUserLeavingRequest;
use App\Http\Requests\User\UserLogRequest;
use App\Http\Resources\Api\Admin\User\UserLogResource;
use App\Http\Resources\UserResource;
use App\Models\Manager;
use App\Models\ManagerUser;
use App\Models\User;
use App\Models\UserLog;
use App\Notifications\EmployeeRequest;
use App\Services\UserService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\DB;

class ManagerUserLogController extends ApiController
{

    public $userService;
    public function __construct( UserService $userService ) {
        parent::__construct();
        $this->userService  = $userService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Manager $manager)
    {
        $userLogs = UserLog::with(['user','approver','requestor'])->where('requestor_id', $manager->user_id)->get();
        return UserLogResource::collection($userLogs);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserLogRequest $request, Manager $manager)
    {
        try{
            return DB::transaction(function () use ($request, $manager) {
                $userData = $this->userService->createNewUser($request, $manager->user_id);
                $user = new ManagerUser(['user_id' => $userData['user']->id]);
                $manager->staffs()->save($user);
                $hrs = $this->userService->getUsersByPermission('hr',$request->office_location_id);
                if($hrs){
                    Notification::send($hrs, new EmployeeRequest($userData['userLog']));
                }
                $updatedUser = User::with('latestUserLog')->where('id',$userData['user']->id)->first();
                return new UserResource($updatedUser);
            });
        }catch(Exception $exception){
            return $this->error('Something Wrong, Please try again '. $exception->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Manager $manager, UserLog $user_log)
    {
        $user_log = $user_log->load(['user','requestor']);
        return new UserLogResource($user_log);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Manager $manager, UserLog $user_log)
    {
        if($user_log->status == 'pending'){
            DB::transaction(function () use ($user_log){
                $user_log->status = 'withdrawn';
                $user_log->save();
                $user_log->delete();
                if( $user_log->type == 'joining'){
                    User::where('id', $user_log->user_id)->delete();
                }

            });

            return $this->success(['message'=>'Deleted Successfully']);
        }else{
           return $this->error('Cant delete this log and its already proccessed ');
        }

    }

      /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function leavingUser(ManagerUserLeavingRequest $request)
    {
        $userLog = $this->userService->userLeavingRequest($request);
        $hrs = $this->userService->getHumanResources();
        if($hrs){
            Notification::send($hrs, new EmployeeRequest($userLog));
        }
        return new UserLogResource($userLog);
    }
}
