<?php

namespace App\Http\Controllers\Api\Admin\Manager;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Manager\ManageMassRequest;
use App\Http\Requests\Admin\Manager\ManagerUserRequest;
use App\Http\Resources\Admin\Manager\ManagerResource;
use App\Http\Resources\UserCollection;
use App\Models\Manager;
use App\Models\ManagerUser;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManagerUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Manager $manager)
    {

       //  $users = $manager->load('staffs');
         $users = Manager::with(['staffs','staffs.user.latestUserLog'])->where('id',$manager->id)->first();
        return new ManagerResource($users);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ManagerUserRequest $request, Manager $manager)
    {
        if($manager->staffs()->where('user_id',$request->user_id)->count() > 0){
            return $this->error("Already added this user");
        }
        $user = new ManagerUser($request->all());
        $manager->staffs()->save($user);
        $manager = $manager->load('staffs');
        return new ManagerResource($manager);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Manager $manager, User $user)
    {
        $deleteResponse = $manager->staffs()->where('user_id',$user->id)->delete();
        if($deleteResponse) {
            return $this->success(['message'=>'Deleted successfully']);
        }else{
            return $this->error('Selected user not available under this manager');
        }

    }

    /**
     * Mass update the manager user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function massUpdate(ManageMassRequest $request){
        return DB::transaction(function () use($request) {

            foreach($request->users AS $user) {
                ManagerUser::updateOrInsert(
                    [
                        'user_id' => $user,
                    ],
                    [
                        'manager_id'  =>$request->manager_id
                    ]
                );
            }
            $managerUsers = Manager::with('staffs')->where('id',$request->manager_id)->first();
            return new ManagerResource($managerUsers);

        });

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function mangersByUserId(User $user)
    {
        $users =  Manager::with('staffs')->where('user_id',$user->id)->first();
        return new ManagerResource($users);
    }
}
