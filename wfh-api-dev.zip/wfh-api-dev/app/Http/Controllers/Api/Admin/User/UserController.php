<?php

namespace App\Http\Controllers\Api\Admin\User;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\UserProfileRequest;
use App\Http\Requests\User\UserRequest;
use App\Http\Requests\User\UserStatusRequest;
use App\Http\Requests\User\UserUploadRequest;
use App\Http\Resources\UserCollection;
use App\Http\Resources\UserResource;
use App\Models\OfficeLocation;
use App\Models\Role;
use App\Models\User;
use App\Services\UserService;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\User\ChangePasswordRequest;
class UserController extends ApiController
{

    public $userService;
    public function __construct( UserService $userService ) {
        parent::__construct();
        $this->userService  = $userService;
    }

    public function index()
    {

        //abort_if(Gate::denies('USER-LIST'), Response::HTTP_FORBIDDEN, 'Un Authorized');
        return new UserCollection(User::with(['officeLocation.country','roles'])->get());
    }

    public function store(UserRequest $request){
        $userData = $this->userService->createNewUser($request, $request->user()->id, true);
        return new UserResource($userData['user']);
    }
    public function show(User $user)
    {
        // abort_if(Gate::denies('USER-SHOW'), Response::HTTP_FORBIDDEN, 'Un Authorized');
        $permissions = $this->userService->getUserPermissions($user->id);
        if (!$user->id) {
            if (Auth::check()) {
                $userRelations = User::with(['roles', 'locations','managerUser.manager.user','managerUser.manager.department', 'isManager.user','officeLocation.country'])->find(Auth::id());
                $userResource = new UserResource($userRelations);
                return $this->userService->userResponse($userResource,$userRelations->id);
            }
            return $this->error('User not found');
        }
        $userRelations = $user->load(['roles', 'locations','managerUser.manager.user', 'managerUser.manager.department','isManager.user', 'officeLocation.country']);
        //return $this->customResponse($user);
        $userResource = new UserResource($userRelations);
        return $this->userService->userResponse($userResource,$user->id);

    }

    public function update(User $user,UserRequest $request)
    {
        //abort_if(Gate::denies('USER-UPDATE'), Response::HTTP_FORBIDDEN, 'Un Authorized');

        $user->fill($request->all());
        if (isset($request->password)) {
            $user->fill(['password' => Hash::make($request->password)]);
        }
        $user->save();

        if($request->has('roles') && count($request->roles)>0){
            $roles = array_filter($request->roles);
            $user->roles()->sync($roles);
        }else{
            $user->roles()->detach();
        }
        $user = $user->load(['locations','officeLocation.country']);
        return new UserResource($user);
    }

    public function importUser(UserUploadRequest $request)
    {
        //abort_if(Gate::denies('USER-UPLOAD'), Response::HTTP_FORBIDDEN, 'Un Authorized');
        $users = $request->users;
        $userData = [];
        foreach ($users AS $user) {
            $user['password'] = Hash::make('Welcome1');
            $userData[] =  $user;
        }

        foreach (array_chunk($userData, 100) as $data) {
            User::upsert(
                $data,
                ['email']
            );
        }
        $role = Role::Default()->first();
        if ($role) {
            $userLists = User::doesntHave('roles')->get();
            foreach ($userLists as $user) {
                $user->roles()->sync($role->id);
            }
        }
        return $this->success(['message' => 'Successfully Uploaded']);
    }

    public function userList(OfficeLocation $officeLocation)
    {
        $users = User::with('officeLocation.country')->where('office_location_id', $officeLocation->id)->get();
        return new UserCollection($users);

    }

    public function destroy(User $user)
    {
        $user->delete();
        return $this->success(['message' => 'deleted successfully']);
    }

    public function uploadProfilePicture(UserProfileRequest $request, User $user)
    {
        $existingImage = $user->getRawOriginal('picture');
        $file = $request->picture;
        $path = $file->store('image', 'public');
        if(Storage::disk('public')->exists($path )) {  // check file exists in directory or not
            $user->picture = $path;
            $user->save();
            Storage::disk('public')->delete($existingImage);
            return new UserResource($user);
        }else {
            return $this->error('Profile picture not uploaded successfully');
        }
    }

    public function updateStatus(UserStatusRequest $request, User $user)
    {
        $user->status = $request->status;
        $user->save();
        return $this->success(['message' => 'successfully updated.']);
    }

    public function deactivateUser(Request $request, User $user)
    {


        if($user->getRawOriginal('status') == '20'){
            return $this->error('Already proccessed');
        }
        $request->merge([
            'user_id'       => $user->id,
            'leaving_date'  => $request->leaving_date ?? Carbon::today(),
            'status'        => 'approved'
        ]);
        try{
            $userLog = $this->userService->userLeavingRequest($request);
           return  $this->userService->userRequestProcess($request, $userLog);
        }catch(Exception $exception){
            return $this->error('Something Wrong, Please try again '. $exception->getMessage());
        }
    }

    public function changePassword(ChangePasswordRequest $request,  User $user)
    {
        $user->password = Hash::make($request->password);
        $user->save();
        return $this->success(['message' => 'Password has been changed']);
    }


}
