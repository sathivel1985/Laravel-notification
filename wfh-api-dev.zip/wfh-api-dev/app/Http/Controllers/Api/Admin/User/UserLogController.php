<?php

namespace App\Http\Controllers\Api\Admin\User;

use App\Http\Controllers\ApiController;
use App\Http\Requests\User\UserLogApprovalRequest;
use App\Http\Resources\Api\Admin\User\UserLogResource;
use App\Models\OfficeLocation;
use App\Models\User;
use App\Models\UserLog;
use App\Services\UserService;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserLogController extends ApiController
{

    public $userService;
    public function __construct( UserService $userService ) {
        parent::__construct();
        $this->userService  = $userService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,OfficeLocation $officeLocation)
    {
        $userLocationCallback = function($query) use ($officeLocation) {
            return $query->where('office_location_id' ,$officeLocation->id);
        } ;

        $userLogs = UserLog::whereHas('user', $userLocationCallback)->with(['user'=>$userLocationCallback,'approver','requestor']);
        if (!empty($request->status) && !empty(array_flip(UserLog::STATUS)[strtolower($request->status)])) {
            $userLogs = $userLogs->where('status', array_flip(UserLog::STATUS)[strtolower($request->status)]);
        }
        $userLogs = $userLogs->orderBy('id', 'DESC')->get();
        return UserLogResource::collection($userLogs);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(UserLog $user_log)
    {
        $user_log = $user_log->load(['user','requestor']);
        return new UserLogResource($user_log);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserLogApprovalRequest $request, UserLog $user_log)
    {
        if( $user_log->status == 'approved' || $user_log->status == 'rejected'){
            return $this->error('Already proccessed');
        }
        if ($user_log->status == 'withdrawn'){
            return $this->error('withdrawn cant process');
        }
        return $this->userService->userRequestProcess($request, $user_log);
    }


}
