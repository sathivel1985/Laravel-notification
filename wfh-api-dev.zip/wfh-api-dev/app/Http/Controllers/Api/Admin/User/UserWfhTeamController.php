<?php

namespace App\Http\Controllers\Api\Admin\User;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Models\PolicyBuilder;
use App\Models\User;
use App\Models\WfhTeam;
use Carbon\Carbon;
use Illuminate\Http\Request;

class UserWfhTeamController extends ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(User $user)
    {
        // $policy = PolicyBuilder::where('office_location_id', $user->office_location_id)
        //     ->latest()
        //     ->first();
        $policy = PolicyBuilder::getLatestPolicyBuilderByOfficeLocation($user->office_location_id);
        if (!$policy) {
            return $this->customResponse(null);
        }
        $callback = function ($query) use ($user) {
            return $query->where('user_id', $user->id);
        };
        $team = WfhTeam::whereHas('userAllocations', $callback)
        ->with('policyBuilder:id,perm_state,occupancy,execution,frequency,essential_list')
        ->where('policy_builder_id', $policy->id)->first();
        $weekAllocations = null;
        $userAllocations = null;
        if ($team) {
            $weekAllocations = $team->weekAllocations()->get();
            $userAllocations = $team->userAllocations()->where('user_id', $user->id)->first();
        }
        $customData = [
            'team' => $team,
            'userAllocation' => $userAllocations,
            'weekAllocation' => $weekAllocations
        ];
        return $this->customResponse($customData);
    }
}
