<?php

namespace App\Http\Controllers\Api\Admin\User;

use App\Http\Controllers\ApiController;
use App\Http\Requests\User\UserRoleRequest;
use App\Http\Resources\RoleResource;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Gate;

class UserRoleController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(User $user)
    {
       // abort_if(Gate::denies('USER-ROLE-LIST'), Response::HTTP_FORBIDDEN, 'Un Authorize');
        $roles = $user->roles()->get();
        return  RoleResource::collection($roles);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRoleRequest $request, User $user)
    {
        //abort_if(Gate::denies('USER-ROLE-ASSIGN'), Response::HTTP_FORBIDDEN, 'Un Authorize');
        $user->roles()->sync($request->roles);
        return RoleResource::collection($user->roles);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user, Role $role)
    {
       // abort_if(Gate::denies('USER-ROLE-DELETE'), Response::HTTP_FORBIDDEN, 'Un Authorize');
        $user->roles()->detach($role->id);
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
