<?php

namespace App\Http\Controllers\Api\Notifications;

use App\Http\Controllers\ApiController;
use App\Models\ManagerUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends ApiController
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (!empty($request->type)) {
            $data = [
                'total' => auth()->user()->notifications->where('notification_type',$request->type)->count(),
                'notifications' => auth()->user()->notifications->where('notification_type',$request->type),
                'totalUnread' => auth()->user()->unreadNotifications->where('notification_type',$request->type)->count()
             ];
        } else {
            $data = [
                'total' => auth()->user()->notifications->count(),
                'notifications' => auth()->user()->notifications,
                'totalUnread' => auth()->user()->unreadNotifications->where('notification_type',$request->type)->count()
             ];
        }

        return $this->customResponse($data);
    }

    public function unread()
    {

        $data = [
            'total' => auth()->user()->unreadNotifications->count(),
            'notifications' => auth()->user()->unreadNotifications->groupBy('notification_type',false)->map(function($row,$key){
                return [
                   'format'=> [
                        'type' => $key,
                        'total' => $row->count()
                    ]
                ];
            })->pluck('format')
        ];
        return $this->customResponse($data);
    }
    public function markAsRead(Request $request)
    {
        if($request->has('id') && !empty($request->id)){
            $notification =  auth()->user()->notifications->where('id',$request->id)->first();
            $notification->markAsRead();
            return $this->customResponse($notification);
        }
        auth()->user()->unreadNotifications->markAsRead();
        return $this->customResponse(auth()->user()->unreadNotifications);
    }
}
