<?php

namespace App\Http\Controllers\Api\WFH\AuditDuration;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\AuditDuration\AuditDurationRequest;
use App\Http\Resources\WFH\AuditDuration\AuditDurationResource;
use App\Models\WfhAuditDuration;


class AuditDurationController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $durations = WfhAuditDuration::all();
        return AuditDurationResource::collection($durations);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AuditDurationRequest $request)
    {
        $duration = WfhAuditDuration::create($request->all());
        return new AuditDurationResource($duration);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(WfhAuditDuration $audit_duration)
    {
        return new AuditDurationResource($audit_duration);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AuditDurationRequest $request, WfhAuditDuration $audit_duration)
    {
        $audit_duration->fill($request->all());
        // if($audit_duration->isClean()) {
        //     return $this->error(['message'=>'Please specify the new value to update']);
        // }
        $audit_duration->save();
        WfhAuditDuration::where('id', '!=', $audit_duration->id)->update(['is_active' => 0]);
        return new AuditDurationResource($audit_duration);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(WfhAuditDuration $audit_duration)
    {
        $audit_duration->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }

}
