<?php

namespace App\Http\Controllers\Api\WFH\Questionaries;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\AuditSections\AuditSectionRequest;
use App\Http\Requests\WFH\AuditSections\AuditSectionSortNumberUpdateRequest;
use App\Http\Resources\WFH\AuditSections\AuditSectionCollection;
use App\Http\Resources\WFH\AuditSections\AuditSectionResource;
use App\Models\Questionary;
use App\Models\WfhAuditSection;

class QuestionarySectionController extends ApiController
{
      /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Questionary $questionary)
    {
        $audit_sections =$questionary->sections()->get();
        return new AuditSectionCollection($audit_sections);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AuditSectionRequest $request, Questionary $questionary)
    {
        $audiSection = new WfhAuditSection($request->all());
        $questionarySection = $questionary->sections()->save($audiSection);
        return new AuditSectionResource($questionarySection);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Questionary $questionary, WfhAuditSection $audit_section)
    {
        return new AuditSectionResource($audit_section);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AuditSectionRequest $request, Questionary $questionary,WfhAuditSection $audit_section)
    {
        $audit_section->fill($request->only(['name', 'icon','content','format','description','sort_no']));
        $audit_section->save();
        return new AuditSectionResource($audit_section);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Questionary $questionary,WfhAuditSection $audit_section)
    {
        if($audit_section->format === 'schedule'){
            return $this->error(['message'=>'Sorry cant delete '.$audit_section->name ]);
        }
        $audit_section->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }

     /**
     * Update the specified array resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateSortNumber(AuditSectionSortNumberUpdateRequest $request)
    {
       foreach ($request->sections AS $section) {
            WfhAuditSection::where('id', $section['id'])->update([
                'sort_no' => $section['sort_no']
            ]);
       }
       return $this->success(['message'=>'Updated Successfully']);
    }
}
