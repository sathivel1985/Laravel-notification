<?php

namespace App\Http\Controllers\Api\WFH\Questionaries;

use App\Http\Controllers\ApiController;
use App\Http\Resources\WFH\Questionary\QuestionaryResource;
use App\Models\OfficeLocation;
use App\Models\Questionary;
use Illuminate\Http\Request;

class UserQuestionarieSectionController extends ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(OfficeLocation $office_location)
    {

        $officeCallback = function($query) use ($office_location) {
            return $query->where('office_location_id',$office_location->id);
        } ;
        $sectionCallback = function($query) {
            return $query->where('format' ,'!=', 'schedule');
        } ;
        $questionaries = Questionary::with(['sections' => $sectionCallback])->whereHas('questionaryOfficeLocations',$officeCallback)->first();
        return new QuestionaryResource($questionaries);
    }
}
