<?php

namespace App\Http\Controllers\Api\WFH\Questionaries;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\Questionary\QuestionaryRequest;
use App\Http\Resources\WFH\Questionary\QuestionaryResource;
use App\Models\OfficeLocation;
use App\Models\Questionary;
use App\Models\QuestionaryOfficeLocation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
class QuestionaryController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(OfficeLocation $office_location)
    {
         // abort_if(Gate::denies('QUESTIONNAIRE'), Response::HTTP_FORBIDDEN, 'Un Authorized');
        $countryLocations= $office_location->country->officeLocations()->pluck('id')->toArray();

        $callback = function($query) use ($countryLocations) {
            return $query->whereIn('office_location_id',$countryLocations);
        } ;
        $questionaries = Questionary::whereHas('questionaryOfficeLocations',$callback)->with(['questionaryOfficeLocations'=>$callback,'questionaryOfficeLocations.officeLocation'])->get();
        return QuestionaryResource::collection($questionaries);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(QuestionaryRequest $request)
    {

        // abort_if(Gate::denies('QUESTIONNAIRE'), Response::HTTP_FORBIDDEN, 'Un Authorized');
        $questionaryOfficeLocation = QuestionaryOfficeLocation::with(['questionary','officeLocation'])->whereIn('office_location_id',$request->office_locations)->get();
        if ((!isset($request->over_write) || !filter_var($request->over_write, FILTER_VALIDATE_BOOLEAN)) && count($questionaryOfficeLocation) > 0 ){
            $questionarysNameList = $questionaryOfficeLocation->pluck('questionary')->flatten()->unique()->implode('preferred_name',',');
            $officeLocationNameList = $questionaryOfficeLocation->pluck('officeLocation')->flatten()->implode('name',',');
            return $this->error([
                'error'   => true,
                'message' => 'Already Exists '.$questionarysNameList.' at '.$officeLocationNameList
            ]);
        }

        return DB::transaction(function () use ($request,$questionaryOfficeLocation){
            $user  = User::with('officeLocation.country')->where('id',$request->user()->id)->first();

            $questionary = Questionary::create([
                'preferred_name' => $request->preferred_name,
                'user_id'        => $user->id,
                'countrie_id'    =>  $user->officeLocation->country->id
            ]);
            if (count($questionaryOfficeLocation) > 0){
                QuestionaryOfficeLocation::whereIn('office_location_id',$request->office_locations)->delete();
            }
            $data = [];
            foreach($request->office_locations AS $location){
                 $data[] = new QuestionaryOfficeLocation(['office_location_id'=>$location]);
            }
            $questionary->questionaryOfficeLocations()->saveMany([
                ...$data
            ]);
            $questionary = $questionary->load('questionaryOfficeLocations');
            return new QuestionaryResource($questionary);
        });


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Questionary $questionary)
    {
        $questionary = $questionary->load(['questionaryOfficeLocations','questionaryOfficeLocations.officeLocation']);
        return new QuestionaryResource($questionary);
    }

     /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(QuestionaryRequest $request, Questionary $questionary)
    {
        // abort_if(Gate::denies('QUESTIONNAIRE'), Response::HTTP_FORBIDDEN, 'Un Authorized');
        $existingQuestionaryLocation = $questionary->questionaryOfficeLocations()->pluck('office_location_id')->toArray();
        $updateLocations = array_diff($request->office_locations,$existingQuestionaryLocation);

        $questionaryOfficeLocation = QuestionaryOfficeLocation::with(['questionary','officeLocation'])->whereIn('office_location_id',$updateLocations)->get();
        if ((!isset($request->over_write) || !filter_var($request->over_write, FILTER_VALIDATE_BOOLEAN)) && count($questionaryOfficeLocation) > 0 ){
            $questionarysNameList = $questionaryOfficeLocation->pluck('questionary')->flatten()->unique()->implode('preferred_name',',');
            $officeLocationNameList = $questionaryOfficeLocation->pluck('officeLocation')->flatten()->implode('name',',');
            return $this->error([
                'error'   => true,
                'message' => 'Already Exists '.$questionarysNameList.' at '.$officeLocationNameList
            ]);
        }

        return DB::transaction(function () use ($request,$questionaryOfficeLocation, $questionary,$existingQuestionaryLocation){
            $questionary->fill(['preferred_name' => $request->preferred_name]);
            $questionary->save();
            $mergeLocations = array_filter(array_merge($existingQuestionaryLocation,$request->office_locations));
            if (count($mergeLocations) > 0){
                QuestionaryOfficeLocation::whereIn('office_location_id',$mergeLocations)->delete();
            }
            $data = [];
            foreach($request->office_locations AS $location){
                 $data[] = new QuestionaryOfficeLocation(['office_location_id'=>$location]);
            }
            $questionary->questionaryOfficeLocations()->saveMany([
                ...$data
            ]);
            $questionary = $questionary->load('questionaryOfficeLocations');
            return new QuestionaryResource($questionary);
        });
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Questionary $questionary)
    {
        // abort_if(Gate::denies('QUESTIONNAIRE'), Response::HTTP_FORBIDDEN, 'Un Authorized');
        $questionary->delete();
        $questionary->questionaryOfficeLocations()->delete();
        return $this->success(['Message'=>'Deleted Successfully']);

    }
}
