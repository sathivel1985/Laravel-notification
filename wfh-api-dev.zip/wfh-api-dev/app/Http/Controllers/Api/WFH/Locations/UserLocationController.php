<?php

namespace App\Http\Controllers\Api\WFH\Locations;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\Locations\UserLocationRequest;
use App\Http\Resources\WFH\Locations\UserLocationCollection;
use App\Http\Resources\WFH\Locations\UserLocationResource;
use App\Models\User;
use App\Models\WfhLocation;

class UserLocationController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(User $user)
    {
        $user_locations = $user->locations()->get();
        return new UserLocationCollection($user_locations);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserLocationRequest $request, User $user)
    {
        $wfh_location = new WfhLocation($request->only('name','address','distance'));
        $user_location =  $user->locations()->save($wfh_location);
        return new UserLocationResource($user_location);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(User $user, WfhLocation $location)
    {
        return new UserLocationResource($location);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserLocationRequest $request,User $user,WfhLocation $location )
    {
        $location->fill($request->all());
         if($location->isClean()) {
            return $this->error(['message'=>'Please specify the new value to update']);
        }
        $location->save();
        return new UserLocationResource($location);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user, WfhLocation $location)
    {
        $location->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }

    /**
     * Return the approved locations from user locations.
     *
     * @param  int  User $user
     * @return \Illuminate\Http\Response
     */
    public function approvedLocations(User $user){
        $locations = $user->approvedLocations;
        return new UserLocationCollection($locations);
    }
}
