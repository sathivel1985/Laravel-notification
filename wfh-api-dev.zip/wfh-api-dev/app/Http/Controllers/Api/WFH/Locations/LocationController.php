<?php

namespace App\Http\Controllers\Api\WFH\Locations;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\Locations\LocationStatusRequest;
use App\Http\Resources\WFH\Locations\UserLocationResource;
use App\Models\WfhLocation;
use Illuminate\Http\Request;

class LocationController extends ApiController
{

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(WfhLocation $location)
    {
        $location = $location->load(['user']);
        return new UserLocationResource($location);
    }

    /**
     * Update the specified location  status.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateStatus(LocationStatusRequest $request)
    {
        $locationid = WfhLocation::where('user_id',$request->user_id)
        ->where('id',$request->location_id)
        ->update([
            'status' =>  $request->status,
            'overriden_by' => $request->user()->id,
            'overriden_at' => date('Y-m-d H:i:s')
            ]);
        if( !$locationid ){
            return $this->error('Status not updated');
        }
        $location = WfhLocation::find( $locationid );
        // $location = $location->load(['user']);
        return new UserLocationResource($location);

    }


}
