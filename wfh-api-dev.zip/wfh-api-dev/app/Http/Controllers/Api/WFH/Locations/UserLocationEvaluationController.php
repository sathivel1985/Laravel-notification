<?php

namespace App\Http\Controllers\Api\WFH\Locations;

use App\Http\Controllers\ApiController;
use App\Http\Resources\WFH\Locations\UserLocationEvaluationResource;

use App\Models\UserLocationEvaluation;
use App\Models\WfhLocation;
use Illuminate\Http\Request;

class UserLocationEvaluationController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(WfhLocation $wfh_location)
    {
        $evaluations = UserLocationEvaluation::with('location')->where('wfh_location_id',$wfh_location->id)->get();
        return UserLocationEvaluationResource::collection($evaluations);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, WfhLocation $wfh_location)
    {
        $listStatus = array_flip(WfhLocation::STATUS);
        $draftEvaluation = $wfh_location->evaluations()->where('status',$listStatus['Draft'])->first();
        if($draftEvaluation){
            $draftEvaluation = $draftEvaluation->load('location');
            return new UserLocationEvaluationResource($draftEvaluation);
        }

        $evaluation = UserLocationEvaluation::create([
            'user_id'           => $request->user()->id,
            'wfh_location_id'   => $wfh_location->id,
            'status'            => $listStatus['Draft']
        ]);
        $evaluation = $evaluation->load('location');
        return new UserLocationEvaluationResource($evaluation);
    }

}
