<?php

namespace App\Http\Controllers\Api\WFH\CoWorkingSpace;

use App\Http\Controllers\ApiController;
use App\Http\Resources\WFH\CoWorkingSpace\CoWorkingSpaceResource;
use App\Models\OfficeLocation;
use Illuminate\Http\Request;

class OfficeLocationCoWorkingSpace extends ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(OfficeLocation $officeLocation)
    {
        $coWorkingSpaces = $officeLocation->coWorkingSpaces()->get();
        return CoWorkingSpaceResource::collection($coWorkingSpaces);
    }
}
