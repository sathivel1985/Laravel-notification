<?php

namespace App\Http\Controllers\Api\WFH\CoWorkingSpace;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\WFH\CoWorkingSpace\CoWorkingSpaceRequest;
use App\Http\Resources\WFH\CoWorkingSpace\CoWorkingSpaceResource;
use App\Models\CoWorkingSpace;
use Illuminate\Http\Request;

class CoWorkingSpaceController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $coWorkSpace = CoWorkingSpace::all();
        return CoWorkingSpaceResource::collection($coWorkSpace);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CoWorkingSpaceRequest $request)
    {
        $coWorkSpace = CoWorkingSpace::create($request->all());
        return new CoWorkingSpaceResource($coWorkSpace);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(CoWorkingSpace $co_working_space)
    {
        return new CoWorkingSpaceResource($co_working_space);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CoWorkingSpaceRequest $request, CoWorkingSpace $co_working_space)
    {
        $co_working_space->fill($request->all());
        $co_working_space->save();
        return new CoWorkingSpaceResource($co_working_space);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(CoWorkingSpace $co_working_space)
    {
        $co_working_space->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
