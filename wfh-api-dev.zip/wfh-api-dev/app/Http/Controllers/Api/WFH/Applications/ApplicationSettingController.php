<?php

namespace App\Http\Controllers\Api\WFH\Applications;

use App\Http\Controllers\ApiController;
use App\Models\WfhApplication;
use App\Models\WfhApplicationReason;
use Illuminate\Http\Request;

class ApplicationSettingController extends ApiController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $settings =[
            'types'   => WfhApplication::listTypes(),
            'reasons' => WfhApplicationReason::orderBy('sort_no')->get(['id','name','state']),
            'days'    => WfhApplication::listDays(),
            'statuses'  => WfhApplication::listStatus()
        ];
        return $this->customResponse($settings);
    }
}
