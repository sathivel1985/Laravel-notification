<?php

namespace App\Http\Controllers\Api\WFH\Applications;

use App\Http\Controllers\Controller;
use App\Http\Resources\WFH\Applications\ApplicationCollection;
use App\Models\WfhApplication;
use Illuminate\Http\Request;

class ApplicationController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $applications = WfhApplication::with(['user','approver','location','reason','dates'])->paginate(50);
        return new ApplicationCollection($applications);
    }


}
