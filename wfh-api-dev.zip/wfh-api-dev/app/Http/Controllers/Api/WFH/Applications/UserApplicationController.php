<?php

namespace App\Http\Controllers\Api\WFH\Applications;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\Applications\ApplicationRequest;
use App\Http\Resources\WFH\Applications\ApplicationCollection;
use App\Http\Resources\WFH\Applications\ApplicationResource;
use App\Models\User;
use App\Models\WfhApplication;
use App\Services\ApplicationService;


class UserApplicationController extends ApiController
{

    public $applicationService;
    public function __construct( ApplicationService $applicationService ) {
        parent::__construct();
        $this->applicationService  = $applicationService;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(User $user)
    {

        // $applications = $user->load(['applications','applications.dates','applications.location','applications.reason']);
        $applications = WfhApplication::with(['approver', 'location', 'reason', 'dates','coWorkingSpace'])->where('user_id', $user->id)->get();

        return new ApplicationCollection($applications);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ApplicationRequest $request)
    {
        $response = $this->applicationService->createApplication($request);
        return $this->customResponse($response);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(User $user, WfhApplication $application)
    {
        $application = $application->load(['dates']);
        return new ApplicationResource($application);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, $id)
    // {
    //     //
    // }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function destroy(User $user, WfhApplication $application)
    // {
    //     $application->delete();
    //     return $this->success(['message' => 'Deleted Successfully']);
    // }
}
