<?php

namespace App\Http\Controllers\Api\WFH\Applications;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\WFH\Applications\ApplicationStatusRequest;
use App\Http\Resources\WFH\Applications\ApplicationCollection;
use App\Http\Resources\WFH\Applications\ApplicationResource;
use App\Http\Resources\WFH\Applications\ManagerApplicationResource;
use App\Models\Manager;
use App\Models\OfficeLocation;
use App\Models\User;
use App\Models\WfhApplication;
use App\Notifications\ApplicationNotifiction;
use App\Services\ApplicationService;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;

class ManagerApplicationController extends ApiController
{
    public $applicationService;
    public function __construct( ApplicationService $applicationService ) {
        parent::__construct();
        $this->applicationService  = $applicationService;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Manager $manager)
    {
        $applications = WfhApplication::with(['user','approver','location','reason','dates'])->wherehas('user.managerUser',
            function (Builder $query) use ($manager) {
                $query->where('manager_id', $manager->id);
            }
        )
        ->get();
        return new ApplicationCollection($applications);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ApplicationStatusRequest $request, Manager $manager, WfhApplication $application)
    {
        // if($manager->user->id !== $request->user()->id){
        //     throw new Exception("Manger has not same as login user");
        // }
        if($application->status !=  (WfhApplication::STATUS)[10] ){
            throw new Exception("Already application has proccessed");
        }
        return DB::transaction(function () use ($application, $request ) {

            if(strtolower($application->state) == 'wfo' && $request->status ==  array_flip(WfhApplication::STATUS)['APPROVED'] ){
                $application->dates()->delete();

                $user = User::where('id', $application->user_id)->first();
                $officeLocation = OfficeLocation::where('id',$user->office_location_id)->first();
                $applicationRequest = [
                    'type'         => $application->getRawOriginal('type'),
                    'state'        => $application->state,
                    'user_id'      => $application->user_id,
                    'start_date'   => $application->getRawOriginal('start_date'),
                    'end_date'     => $application->getRawOriginal('end_date'),
                    'policy_builder_id' =>  $application->policy_builder_id,
                    'recurring_days'    => !empty($application->getRawOriginal('recurring_days')) ?
                    json_decode($application->getRawOriginal('recurring_days')) : '',
                    'specific_days'   => $application->dates->pluck('date')->all(),
                    'over_write'    => true
                   ];

                $applicationDates = $this->applicationService->validateApplicationDateForWfo($application,$user, $officeLocation,  $applicationRequest);

                $application->update([
                    'status'      => $request->status,
                    'approver_id' => $request->user()->id,
                    'status_date' => date('Y-m-d H:i:s')
                ]);

               // Notification::send($user, new ApplicationNotifiction($application,'manager'));

                return [
                    'success' => true,
                    'error'   => null,
                    'applicationDates' => $applicationDates
                ];

            }
            if(strtolower($application->state) == 'wfh' ||  ( strtolower($application->state) == 'wfo' && $request->status !=  array_flip(WfhApplication::STATUS)['APPROVED']) ){

                $updatedId = $application->update([
                    'status'      => $request->status,
                    'approver_id' => $request->user()->id,
                    'status_date' => date('Y-m-d H:i:s')
                ]);

                $updatedApplication = WfhApplication::with(['user','approver','location','reason','dates'])->where('id',$application->id)->first();
                Notification::send($application->user, new ApplicationNotifiction($updatedApplication,'manager'));
                return new ApplicationResource($updatedApplication);
            }



        });


    }

     /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Manager $manager,WfhApplication $application)
    {
        $application = $application->load(['dates','reason','location']);
        if(strtolower($application->state) == 'wfh') {
            $custom = [
                'validation' => null,
                'application' => $application
            ];
            return new ManagerApplicationResource($custom);
        }

        $request = [
         'type'         => $application->getRawOriginal('type'),
         'state'        => $application->state,
         'user_id'      => $application->user_id,
         'start_date'   => $application->getRawOriginal('start_date'),
         'end_date'     => $application->getRawOriginal('end_date'),
         'policy_builder_id' =>  $application->policy_builder_id,
         'recurring_days'    => !empty($application->getRawOriginal('recurring_days')) ?
         json_decode($application->getRawOriginal('recurring_days')) : '',
         'specific_days'   => $application->dates->pluck('date')->all()
        ];

       $validation =  ($application->getRawOriginal('status') != array_flip(WfhApplication::STATUS)['APPROVED']) ? $this->applicationService->createWfoApplication($request): null;
        $custom = [
            'validation' => $validation,
            'application' => $application
        ];
        return new ManagerApplicationResource($custom);
    }
}
