<?php

namespace App\Http\Controllers\Api\WFH\Schedules;

use App\Http\Controllers\Controller;
use App\Http\Requests\WFH\Schedules\SchedulesRequest;
use App\Http\Resources\WFH\Schedules\SchedulesResource;
use App\Models\WfhSchedule;
use Illuminate\Http\Request;

class SchedulesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $schedules = WfhSchedule::all();
        return SchedulesResource::collection($schedules);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // public function store(Request $request)
    // {
    //     //
    // }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function show($id)
    // {
    //     //
    // }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(SchedulesRequest $request, WfhSchedule $schedule)
    {
        $schedule->fill($request->all());
        $schedule->save();
        WfhSchedule::where('id', '!=', $schedule->id)->update(['is_active' => 0]);
        return new SchedulesResource($schedule);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function destroy($id)
    // {
    //     //
    // }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function activeSchedule(Request $request)
    {
        $schedule = WfhSchedule::active()->first();

        return new SchedulesResource($schedule);
    }

}
