<?php

namespace App\Http\Controllers\Api\WFH\AuditSections;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\AuditSections\AuditSectionAnswerCheckRequest;
use App\Http\Requests\WFH\AuditSections\AuditSectionAnswerEvaluationRequest;
use App\Http\Requests\WFH\AuditSections\AuditSectionAnswerRequest;
use App\Http\Resources\WFH\AuditSections\AuditSectionQuestionCollection;
use App\Models\UserLocationEvaluation;
use App\Models\WfhAuditSectionAnswer;
use App\Models\WfhAuditSectionQuestion;
use App\Models\WfhLocation;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
class AuditSectionAnswerController extends ApiController
{

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AuditSectionAnswerRequest $request)
    {

        $location_id = $request->location_id;
        $user_id    = $request->user()->id;
        foreach ($request->answers as $answer) {

            $existAnswer = DB::table('wfh_audit_section_answers')->where([
                'wfh_audit_section_question_id' => $answer['question_id'],
                'user_id'                       => $user_id,
                'wfh_location_id'               => $location_id,
                'user_location_evaluation_id'   => $request->user_location_evaluation_id,
            ])->first();

            if ($existAnswer) {
                DB::table('wfh_audit_section_answers')->where('id', $existAnswer->id)
                ->update([
                    'answer'      => $answer['answer'],
                    'updated_at'  => Carbon::now(),
                ]);
            } else {
                DB::table('wfh_audit_section_answers')->insert([
                    'wfh_audit_section_question_id' => $answer['question_id'],
                    'user_id'                       => $user_id,
                    'wfh_location_id'               => $location_id,
                    'user_location_evaluation_id'   => $request->user_location_evaluation_id,
                    'answer'                        => $answer['answer'],
                    'created_at'                  =>  Carbon::now(),
                    'updated_at'                    => Carbon::now(),
                ]);
            }
            // WfhAuditSectionAnswer::updateOrInsert(
            //     [
            //         'wfh_audit_section_question_id' => $answer['question_id'],
            //         'user_id'     => $user_id,
            //         'wfh_location_id' => $location_id,
            //         'user_location_evaluation_id' => $request->user_location_evaluation_id,
            //     ],
            //     [
            //         'answer'      => $answer['answer'],
            //         'updated_at'                   => Carbon::now(),
            //         'created_at'                  =>  Carbon::now(),
            //     ]
            // );
        }
        return $this->success(['Message' => 'Answer Updated Successfully']);
    }

    /**
     * Return the response audit question response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function auditCheck(AuditSectionAnswerCheckRequest $request)
    {

        $questions = WfhAuditSectionQuestion::with(['answer' => function ($query) use ($request) {
            $query->where('user_id', $request->user_id)
                ->where('wfh_location_id', $request->location_id)
                ->where('user_location_evaluation_id', $request->user_location_evaluation_id);
        }])
        ->where('wfh_audit_section_id', $request->section_id)
        ->orderBy('id')
        ->get();
        return new AuditSectionQuestionCollection($questions);
    }

    /* Return the response audit question response.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
    public function auditEvaluation(AuditSectionAnswerEvaluationRequest $request)
    {

        $questions = WfhAuditSectionQuestion::with(['oneAnswer' => function ($query) use ($request) {
            return $query->where('user_id', $request->user_id)
                ->where('wfh_location_id', $request->location_id)
                ->where('user_location_evaluation_id', $request->user_location_evaluation_id);
        }])
            ->get()
            ->filter(function ($item) {
                $wrongAnswer = [];

                if (empty($item->oneAnswer->answer) || strtolower($item->oneAnswer->answer) !== strtolower($item['ideal_answer'])) {
                    $wrongAnswer[] = [
                        'id'          => $item['id'],
                        'question'    => $item['question'],
                        'ideal_answer' => $item['ideal_answer'],
                        'answer'      => $item->oneAnswer->answer ?? ''
                    ];
                }
                return $wrongAnswer;
            });

        $listStatus = array_flip(WfhLocation::STATUS);
        // DO NOT REMOVE evaluationStatus
        // $evaluationStatus = ($questions->count() == 0) ? $listStatus['Passed'] : $listStatus['Did-Not-Pass'];
        $evaluationStatus = $listStatus['Passed'];

        UserLocationEvaluation::where('id', $request->user_location_evaluation_id)
            ->update(['status' =>  $evaluationStatus]);
        /** update the user location latest status **/
        $userLocationLatestEvaluation = UserLocationEvaluation::where('wfh_location_id',$request->location_id)->latest()->first();
        WfhLocation::where('user_id', $request->user_id)
            ->where('id', $request->location_id)
            ->update([
                'status' =>  $userLocationLatestEvaluation->status,
                'user_location_evaluation_id' => $userLocationLatestEvaluation->id
            ]);
        /** update the user location latest status **/
        return $this->success(['message' => 'successfully validated', 'evaluation_status' => WfhLocation::STATUS[$evaluationStatus]]);
    }
}
