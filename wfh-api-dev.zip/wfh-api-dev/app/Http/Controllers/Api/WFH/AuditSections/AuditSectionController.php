<?php

namespace App\Http\Controllers\Api\WFH\AuditSections;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\AuditSections\AuditSectionRequest;
use App\Http\Resources\WFH\AuditSections\AuditSectionCollection;
use App\Http\Resources\WFH\AuditSections\AuditSectionResource;
use App\Models\WfhAuditSection;
use Illuminate\Http\Request;

class AuditSectionController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $audit_sections = WfhAuditSection::all(['id','name','icon','content','format', 'description']);
        return new AuditSectionCollection($audit_sections);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AuditSectionRequest $request)
    {
        $audit_section = WfhAuditSection::create($request->all());
        return new AuditSectionResource($audit_section);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(WfhAuditSection $audit_section)
    {
        return new AuditSectionResource($audit_section);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AuditSectionRequest $request, WfhAuditSection $audit_section)
    {
        $audit_section->fill($request->only(['name', 'icon','content','format','description','sort_no']));
        $audit_section->save();
        return new AuditSectionResource($audit_section);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(WfhAuditSection $audit_section)
    {
        $audit_section->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
