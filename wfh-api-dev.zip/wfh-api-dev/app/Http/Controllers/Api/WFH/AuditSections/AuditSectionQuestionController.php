<?php

namespace App\Http\Controllers\Api\WFH\AuditSections;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\AuditSections\AuditSectionQuestionRequest;
use App\Http\Resources\WFH\AuditSections\AuditSectionQuestionCollection;
use App\Http\Resources\WFH\AuditSections\AuditSectionQuestionResource;
use App\Models\WfhAuditSection;
use App\Models\WfhAuditSectionQuestion;
use Illuminate\Http\Request;

class AuditSectionQuestionController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(WfhAuditSection $audit_section)
    {
        $auditQuestions = $audit_section->auditQuestions()->get();
        return new AuditSectionQuestionCollection($auditQuestions);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AuditSectionQuestionRequest $request, WfhAuditSection $audit_section)
    {
        $auditQuestion = new WfhAuditSectionQuestion($request->only('question','mandatory', 'ideal_answer','title'));
        $question =  $audit_section->auditQuestions()->save($auditQuestion);
        return new AuditSectionQuestionResource($question);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(WfhAuditSection $audit_section,WfhAuditSectionQuestion $question)
    {
        $question = $question->load('auditSection');
        return new AuditSectionQuestionResource($question);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AuditSectionQuestionRequest $request, WfhAuditSection $audit_section, WfhAuditSectionQuestion $question)
    {
        $question->fill($request->all());
        if($question->isClean()) {
           return $this->error(['message'=>'Please specify the new value to update']);
       }
       $question->save();
       return new AuditSectionQuestionResource($question);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(WfhAuditSection $audit_section, WfhAuditSectionQuestion $question)
    {
        $question->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }
}
