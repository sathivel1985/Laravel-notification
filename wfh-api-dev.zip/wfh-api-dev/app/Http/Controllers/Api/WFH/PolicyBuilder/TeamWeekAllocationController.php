<?php

namespace App\Http\Controllers\Api\WFH\PolicyBuilder;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\WFH\PolicyBuilder\TeamWeekAllocationRequest;
use App\Http\Resources\WFH\PolicyBuilder\TeamWeekAllocationResource;
use App\Models\WfhTeam;
use App\Models\WfhTeamWeekAllocation;
use Illuminate\Http\Request;

class TeamWeekAllocationController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index( WfhTeam $team )
    {
        $weekAllocations = WfhTeamWeekAllocation::with('wfhTeam')->where('wfh_team_id',$team->id)
        ->orderBy('year')->orderBy('week_number')->orderBy('date')->get();
        return TeamWeekAllocationResource::collection($weekAllocations);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(TeamWeekAllocationRequest $request, WfhTeamWeekAllocation $team_allocation)
    {
        $team_allocation->fill($request->only(['wfh_team_id']));
        $team_allocation->save();
        return $this->success(['message' => 'updated successfully']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
