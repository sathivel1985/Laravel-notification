<?php

namespace App\Http\Controllers\Api\WFH\PolicyBuilder;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Requests\WFH\PolicyBuilder\PolicyBuilderRequest;
use App\Http\Resources\WFH\PolicyBuilder\PolicyBuilderResource;
use App\Models\Department;
use App\Models\OfficeLocation;
use App\Models\PolicyBuilder;
use App\Models\WfhTeamUserAllocation;
use App\Models\WfhTeamWeekAllocation;
use App\Services\DateService;
use App\Services\PolicyBuilderService;
use Carbon\Carbon;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PolicyBuilderController extends ApiController
{

    public $policyBuilderService;
    public $dateService;
    public function __construct(PolicyBuilderService $policyBuilderService, DateService $dateService)
    {
        parent::__construct();
        $this->policyBuilderService = $policyBuilderService;
        $this->dateService = $dateService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(OfficeLocation $office_location, Request $request)
    {
        $isFormBuilder = $request->is_formbuilder ?? null;
        $policyBuilder = PolicyBuilder::getLatestPolicyBuilderByOfficeLocation($office_location->id, $isFormBuilder);
        if( !$policyBuilder ){
            return $this->customResponse(null);
        }
        return new PolicyBuilderResource($policyBuilder);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PolicyBuilderRequest $request)
    {

        return DB::transaction(function () use ($request) {

            $requestArray = $request->all();
            $requestArray['user_id'] =  $request->user()->id;
            // $start = Carbon::createFromFormat('Y-m-d', $request->start_date);
            // $end = Carbon::createFromFormat('Y-m-d', $request->end_date);
            $start = date('Y-m-d',strtotime($request->start_date));
            $end =  date('Y-m-d',strtotime($request->end_date));

            $policy = PolicyBuilder::create($requestArray);
            $teams = [];
            if (isset($requestArray['execution']) && strtolower($requestArray['execution']) == 'department') {
                $teams = Department::where('office_location_id', $request->office_location_id)->pluck('name')->all();
            }

            if (isset($requestArray['execution']) and strtolower($requestArray['execution']) == 'team') {
                $teams = $requestArray['teams'];
            }

            if ($teams) {
                $teamArray = [];
                foreach ($teams as $team) {
                    $teamArray[] = ['name' => $team];
                }
                $policy->wfhTeams()->createMany($teamArray);
            }
            $policyTeams = $policy->wfhTeams()->pluck('id')->all();
            if (isset($requestArray['frequency']) and  strtolower($requestArray['frequency']) == 'weeks') {
                $weekArray = $this->dateService->getWeekNumberArray($start, $end);

                $this->policyBuilderService->weekAllocation($weekArray, $policyTeams);
            }
            if (isset($requestArray['frequency']) and  strtolower($requestArray['frequency']) == 'days') {
                $weekDayArray = $this->dateService->getSelectedDayArray($start, $end, $requestArray['recurring_days']);
                $officeLocation = OfficeLocation::where('id',$request->office_location_id)->first();
                $exculedHolidays = $this->dateService->excludeHoliday($weekDayArray, $officeLocation);
                $this->policyBuilderService->dayAllocation($exculedHolidays, $policyTeams);
            }
            if ( $requestArray['occupancy'] == 0 ) {
                $this->policyBuilderService->createUserAllocationByTeam($policyTeams,$request->office_location_id);
            }

            $policy = $policy->load(['wfhTeams','wfhTeamWeekAllocations.wfhTeam','wfhTeamUserAllocations.user','wfhTeamUserAllocations.wfhTeam']);
            return new PolicyBuilderResource($policy);
        });
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(PolicyBuilder $policy_builder)
    {
        $policyBuilder = $policy_builder->load('wfhTeams');
        return new PolicyBuilderResource($policyBuilder);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PolicyBuilderRequest $request, PolicyBuilder $policy_builder)
    {

        return DB::transaction(function () use ($request, $policy_builder) {
            // wfo stop excution all allocations
            $requestArray = $request->all();
            $policy_builder->fill($request->all());
            $policy_builder->save();
            // $start = Carbon::createFromFormat('Y-m-d', $request->start_date);
            // $end = Carbon::createFromFormat('Y-m-d', $request->end_date);
            $start = date('Y-m-d',strtotime($request->start_date));
            $end =  date('Y-m-d',strtotime($request->end_date));
            /**
             * delete all the subtable of policy builder
             */
            $teamIds = $policy_builder->wfhTeams()->pluck('id')->all();
            WfhTeamWeekAllocation::whereIn('wfh_team_id', $teamIds)->delete();
            $policy_builder->wfhTeams()->delete();

            $teams = [];
            if (isset($requestArray['execution']) and strtolower($requestArray['execution']) == 'department') {
                $teams = Department::where('office_location_id', $request->office_location_id)->pluck('name')->all();
            }

            if (isset($requestArray['execution']) and strtolower($requestArray['execution']) == 'team') {
                $teams = $requestArray['teams'];
            }

            if ($teams) {
                $teamArray = [];
                foreach ($teams as $team) {
                    $teamArray[] = ['name' => $team];
                }
                $policy_builder->wfhTeams()->createMany($teamArray);
            }
            $policyTeams = $policy_builder->wfhTeams()->pluck('id')->all();

            if (isset($requestArray['frequency']) and  strtolower($requestArray['frequency']) == 'weeks') {
                $weekArray = $this->dateService->getWeekNumberArray($start, $end);
                $this->policyBuilderService->weekAllocation($weekArray, $policyTeams);
            }
            if (isset($requestArray['frequency']) and  strtolower($requestArray['frequency']) == 'days') {
                $weekDayArray = $this->dateService->getSelectedDayArray($start, $end, $requestArray['recurring_days']);
                $officeLocation = OfficeLocation::where('id',$request->office_location_id)->first();
                $exculedHolidays = $this->dateService->excludeHoliday($weekDayArray, $officeLocation);
                $this->policyBuilderService->dayAllocation($exculedHolidays, $policyTeams);
            }

            if ($requestArray['occupancy'] == 0) {
                $this->policyBuilderService->createUserAllocationByTeam($policyTeams,$request->office_location_id);
            }

            $policy_builder = $policy_builder->load(['wfhTeams','wfhTeamWeekAllocations.wfhTeam','wfhTeamUserAllocations.user','wfhTeamUserAllocations.wfhTeam']);
            return new PolicyBuilderResource($policy_builder);
        });
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(PolicyBuilder $policy_builder)
    {
        return DB::transaction(function () use($policy_builder) {
            $teamIds = $policy_builder->wfhTeams()->pluck('id')->all();
            WfhTeamWeekAllocation::whereIn('wfh_team_id', $teamIds)->delete();
            WfhTeamUserAllocation::whereIn('wfh_team_id', $teamIds)->delete();
            $policy_builder->applications()->delete();
            $policy_builder->wfhTeams()->delete();
            $policy_builder->delete();
            return $this->success(['message' => 'Deleted Successfully']);
        });
    }
}
