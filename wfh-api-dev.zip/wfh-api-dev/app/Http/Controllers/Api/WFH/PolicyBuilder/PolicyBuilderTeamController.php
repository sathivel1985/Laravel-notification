<?php

namespace App\Http\Controllers\Api\WFH\PolicyBuilder;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\PolicyBuilder\PolicyBuilderTeamRequest;
use App\Http\Resources\WFH\PolicyBuilder\PolicyBuilderTeamResource;
use App\Models\PolicyBuilder;
use App\Models\WfhTeam;
use Illuminate\Http\Request;

class PolicyBuilderTeamController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(PolicyBuilder $policy_builder)
    {
        $wfhTeams =  $policy_builder->wfhTeams()->get();
        return PolicyBuilderTeamResource::collection($wfhTeams);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PolicyBuilderTeamRequest $request, PolicyBuilder $policy_builder)
    {
        $policy_builder->wfhTeams()->create($request->only(['name']));
        $wfhTeams =  $policy_builder->wfhTeams()->get();
        return PolicyBuilderTeamResource::collection($wfhTeams);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(PolicyBuilder $policy_builder,WfhTeam $wfhTeam)
    {
        return new PolicyBuilderTeamResource($wfhTeam);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PolicyBuilderTeamRequest $request, PolicyBuilder $policy_builder,WfhTeam $team)
    {

        $team->fill($request->all());
        if($team->isClean()) {
           return $this->error(['message'=>'Please specify the new value to update']);
       }
       $team->save();
       return new PolicyBuilderTeamResource($team);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(PolicyBuilder $policy_builder,WfhTeam $wfhTeam)
    {
        $wfhTeam->delete();
        return $this->success(['message' => 'Deleted Successfully']);
    }
}
