<?php

namespace App\Http\Controllers\Api\WFH\PolicyBuilder;

use App\Http\Controllers\ApiController;
use App\Http\Requests\WFH\PolicyBuilder\TeamMassUserUploadRequest;
use App\Http\Requests\WFH\PolicyBuilder\TeamUserAllocationRequest;
use App\Http\Resources\UserResource;
use App\Http\Resources\WFH\PolicyBuilder\TeamUserAllocationResource;
use App\Models\WfhTeam;
use App\Models\WfhTeamUserAllocation;
use Illuminate\Http\Request;

class TeamUserAllocationController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(WfhTeam $team)
    {
        $team =   WfhTeamUserAllocation::with('user')->where('wfh_team_id',$team->id)->get();
        return TeamUserAllocationResource::collection($team);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TeamUserAllocationRequest $request, WfhTeam $team)
    {
        $team->userAllocations()->create($request->all());
        $team =   WfhTeamUserAllocation::with('user')->where('wfh_team_id',$team->id)->get();
        return TeamUserAllocationResource::collection($team);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( WfhTeam $team,WfhTeamUserAllocation $user_allocation)
    {
        $user_allocation->delete();
        return $this->success(['message'=>'Deleted Successfully']);
    }

    /**
     * upload team user
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function uploadTeamUsers(TeamMassUserUploadRequest $request)
    {
        $notSuccessfull = [];
        foreach($request->users AS $user){
            $team =  WfhTeam::where([
                'name' => $user['team'],
                'policy_builder_id'  => $request->policy_builder_id
            ])->first();
            if(!$team) {
                $notSuccessfull[] = $user['team'];
                continue;
            }
            WfhTeamUserAllocation::updateOrCreate(
                [
                    'user_id'     => $user['user_id']
                ],
                [
                    'wfh_team_id' => $team->id,
                    'is_essential'    => !empty($user['essential']) ? 1:0
                ]
            );
        }
        $message = "Successfully uploaded. ";
        if ($notSuccessfull) {
            $message = "Failed to upload this teams users ".implode(',', $notSuccessfull);
        }
        return $this->success(['message' => $message]);
    }
}
