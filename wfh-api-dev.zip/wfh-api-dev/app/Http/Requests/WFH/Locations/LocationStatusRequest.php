<?php

namespace App\Http\Requests\WFH\Locations;

use App\Models\WfhLocation;
use Illuminate\Foundation\Http\FormRequest;

class LocationStatusRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_id'    => 'required|integer',
            'status'     => 'required|in:'.implode(',',array_keys(WfhLocation::STATUS)),
            'location_id'=> 'required|integer'
        ];
    }
}
