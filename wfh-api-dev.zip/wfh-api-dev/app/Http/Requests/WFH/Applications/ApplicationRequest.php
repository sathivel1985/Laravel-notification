<?php

namespace App\Http\Requests\WFH\Applications;

use App\Models\WfhApplication;
use App\Models\WfhApplicationReason;
use Illuminate\Foundation\Http\FormRequest;

class ApplicationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {


        return [
            'type'              => 'required|in:'.implode(',',array_keys(WfhApplication::APPLICATIONTYPE)),
            'start_date'        => 'required_unless:type,!=,SPECIFIC_DAY',
            'end_date'          => 'required_unless:type,!=,SPECIFIC_DAY',
            'recurring_days'     => 'required_if:type,RECURRING|array',
            'wfh_application_reason_id' => 'required|in:'.WfhApplicationReason::all('id')->implode('id', ', '),
            'specific_days'     => 'required_if:type,SPECIFIC_DAY|array',
            'state'             => 'required|in:wfo,wfh',
            'policy_builder_id'     => 'required_if:state,wfo|integer',
        ];
    }
}
