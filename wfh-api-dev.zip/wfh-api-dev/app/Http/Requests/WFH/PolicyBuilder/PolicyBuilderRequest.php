<?php

namespace App\Http\Requests\WFH\PolicyBuilder;

use App\Models\PolicyBuilder;
use Illuminate\Foundation\Http\FormRequest;

class PolicyBuilderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $permState = array_map(function ($value) {
            return strtolower($value);
        }, array_values(PolicyBuilder::PERM_STATE));

        $frequency = array_map(function ($value) {
            return strtolower($value);
        }, array_values(PolicyBuilder::FREQUENCY));

        $execution = array_map(function ($value) {
            return strtolower($value);
        }, array_values(PolicyBuilder::EXECUTION));

        return [
            'perm_state'        => 'required|in:'.implode(',',$permState),
            'start_date'        => 'required_if:perm_state,wfh|required_if:perm_state,WFH|required_if:perm_state,Wfh',
            'end_date'          => 'required_if:perm_state,wfh|required_if:perm_state,WFH|required_if:perm_state,Wfh',
            'occupancy'         => 'required_if:perm_state,wfh|required_if:perm_state,WFH|required_if:perm_state,Wfh',
            //'essential_list'    => 'required_if:perm_state,wfh|required_if:perm_state,WFH|required_if:perm_state,Wfh',
            'office_location_id'=> 'required_if:perm_state,wfh|required_if:perm_state,WFH|required_if:perm_state,Wfh',
            'execution'         => 'required_if:perm_state,wfh|required_if:perm_state,WFH|required_if:perm_state,Wfh',
            'frequency'         => 'required_if:perm_state,wfh|required_if:perm_state,WFH|required_if:perm_state,Wfh',
            'teams'             => 'required_if:execution,team|array',
            'recurring_days'    => 'required_if:frequency,days|array',
        ];
    }
}
