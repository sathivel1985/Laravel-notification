<?php

namespace App\Http\Resources\Admin\Country;

use App\Http\Resources\Admin\Department\DepartmentResource;
use Illuminate\Http\Resources\Json\JsonResource;

class OfficeLocationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return  [
            'id'       => $this->id,
            'name'     => $this->name,
            'address'  => $this->address,
            'country'  => new CountryResource($this->whenLoaded('country')),
            'departments'  => DepartmentResource::collection($this->whenLoaded('departments'))
        ];
    }
}
