<?php

namespace App\Http\Resources\Admin\Department;

use App\Http\Resources\Admin\Country\OfficeLocationResource;
use App\Http\Resources\Admin\Manager\ManagerResource;
use App\Http\Resources\Admin\Manager\ManagerStaffResource;
use App\Http\Resources\UserResource;
use Illuminate\Http\Resources\Json\JsonResource;

class DepartmentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return  [
            'id'                => $this->id,
            'name'              => $this->name,
            'office_location_id'=> $this->office_location_id,
            'officeLocation'    => new OfficeLocationResource($this->whenLoaded('officeLocation')),
            'manager'           => new ManagerResource($this->whenLoaded('manager')),
            'departmentUser'    =>  ManagerStaffResource::collection($this->whenLoaded('departmentUser'))
        ];
    }
}
