<?php

namespace App\Http\Resources\Admin\Manager;

use App\Http\Resources\Admin\Department\DepartmentResource;
use App\Http\Resources\UserResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ManagerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(empty($this->id)){
            return [];
        }
        return [
            'id'        => $this->id,
            'user_id'   => $this->user_id,
            'department_id'   => $this->department_id,
            'user'      => new UserResource($this->whenLoaded('user')),
            'staff'     => ManagerStaffResource::collection($this->whenLoaded('staffs')),
            'department' => new DepartmentResource($this->whenLoaded('department'))

        ];
    }
}
