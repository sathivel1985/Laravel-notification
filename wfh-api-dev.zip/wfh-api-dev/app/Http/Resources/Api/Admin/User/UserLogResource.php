<?php

namespace App\Http\Resources\Api\Admin\User;

use App\Http\Resources\UserResource;
use Illuminate\Http\Resources\Json\JsonResource;

class UserLogResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(empty($this->id)){
            return null;
        }
        return [
            'id'         => $this->id,
            'type'       => $this->type,
            'status'     => $this->status,
            'typeDate'  => $this->type_date,
            'statusDate'=> $this->status_date,
            'userId'    => $this->user_id,
            'requestorId'=> $this->requestor_id,
            'user'       => new UserResource($this->whenLoaded('user')),
            'requestor'  => new UserResource($this->whenLoaded('requestor')),
            'approver'    => new UserResource($this->whenLoaded('approver')),
        ];
    }
}
