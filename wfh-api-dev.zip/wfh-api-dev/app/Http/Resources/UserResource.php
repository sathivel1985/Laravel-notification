<?php

namespace App\Http\Resources;

use App\Http\Resources\Admin\Country\OfficeLocationResource;
use App\Http\Resources\Admin\Department\DepartmentResource;
use App\Http\Resources\Admin\Manager\ManagerResource;
use App\Http\Resources\Admin\Manager\ManagerStaffResource;
use App\Http\Resources\Api\Admin\User\UserLogResource;
use App\Http\Resources\WFH\Locations\UserLocationCollection;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{

    private $token = null;

    public function __construct($resource, $tokens = null)
    {
        parent::__construct($resource);
        $this->token = $tokens;
    }

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(empty($this->id)){
            return null;
        }
        $data = [
            'id'                => $this->id,
            'name'              => $this->full_name,
            'preferred_name'    => $this->preferred_name,
            'email'             => $this->email,
            'first_name'        => $this->first_name,
            'last_name'         => $this->last_name,
            'designation'       => $this->designation,
            'google2fa_secret'  => $this->google2fa_secret,
            'personal_email'    => $this->personal_email,
            'gender_pronoun'    => $this->gender_pronoun,
            'joining_date'      => $this->joining_date,
            'leaving_date'      => $this->leaving_date,
            'picture'           => $this->picture,
            'status'            => ucfirst($this->status),
            'roles'             => RoleResource::collection($this->whenLoaded('roles')),
            'locations'         => new UserLocationCollection($this->whenLoaded('locations')),
            'isManager'         => new ManagerResource($this->whenLoaded('isManager')),
            'userManager'       => new ManagerStaffResource($this->whenLoaded('managerUser')),
            'staffs'            => ManagerStaffResource::collection($this->whenLoaded('staffs')),
            'officeLocation'    => new OfficeLocationResource($this->whenLoaded('officeLocation')),
            'userLatestLog'     => new UserLogResource($this->whenLoaded('latestUserLog'))
        ];
        if(!empty($this->token)) {
            $data = array_merge($data,['token' => $this->token]);
        }
        return $data;
    }
}
