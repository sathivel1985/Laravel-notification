<?php

namespace App\Http\Resources\WFH\Questionary;

use App\Http\Resources\Admin\Country\OfficeLocationResource;
use App\Http\Resources\WFH\AuditSections\AuditSectionCollection;
use Illuminate\Http\Resources\Json\JsonResource;

class QuestionaryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'                => $this->id,
            'preferredName'     => $this->preferred_name,
            'QuestionaryofficeLocations'   => QuestionaryOfficeLocationResource::collection($this->whenLoaded('questionaryOfficeLocations')),
            'sections'          => new AuditSectionCollection($this->whenLoaded('sections'))
        ];
    }
}
