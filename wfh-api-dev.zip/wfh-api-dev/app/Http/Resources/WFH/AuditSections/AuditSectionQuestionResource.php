<?php

namespace App\Http\Resources\WFH\AuditSections;

use Illuminate\Http\Resources\Json\JsonResource;

class AuditSectionQuestionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(empty($this->id)) {
            return null;
        }

        return [
            'id'                => $this->id,
            'question'          => $this->question,
            'isMandatory'       => $this->mandatory,
            'idealAnswer'       => $this->ideal_answer,
            'hidingQuestion'    => $this->hiding_question,
            'section'           => new AuditSectionResource($this->whenLoaded('auditSection')),
            'answer'            => new AuditSectionAnswerResource($this->whenLoaded('answer')),
            'title'             => $this->title
        ];
    }
}
