<?php

namespace App\Http\Resources\WFH\Applications;

use Illuminate\Http\Resources\Json\JsonResource;

class ApplicationDatesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(empty($this->id)){
            return null;
        }
        return [
            'id'    => $this->id,
            'date'  => $this->date,
        ];
    }
}
