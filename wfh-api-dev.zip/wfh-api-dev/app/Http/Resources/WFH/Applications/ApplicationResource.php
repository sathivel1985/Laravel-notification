<?php

namespace App\Http\Resources\WFH\Applications;

use App\Http\Resources\UserResource;
use App\Http\Resources\WFH\CoWorkingSpace\CoWorkingSpaceResource;
use App\Http\Resources\WFH\Locations\UserLocationResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ApplicationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        //return parent::toArray($request);

        if(empty($this->id)){
            return null;
        }

        return [
            'id'                => $this->id,
            'type'              => $this->type,
            'state'             => $this->state,
            'start_date'        => $this->start_date,
            'end_date'          => $this->end_date,
            'recurring_days'    => $this->recurring_days,
            'wfh_location_id'   => $this->wfh_location_id,
            'co_working_space_id'=> $this->co_working_space_id,
            'location'          => new UserLocationResource($this->whenLoaded('location')),
            'co_working_space'  => new CoWorkingSpaceResource($this->whenLoaded('coWorkingSpace')),
            'reason'            => new ApplicationReasonResource($this->whenLoaded('reason')),
            'reason_other'      => $this->reason_other,
            'location_status'   => $this->location_status,
            'user'              => new UserResource($this->whenLoaded('user')),
            'approver'          => new UserResource($this->whenLoaded('approver')),
            'status_date'       => $this->status_date,
            'status'            => $this->status,
            'dates'             =>  ApplicationDatesResource::collection($this->whenLoaded('dates'))

        ];
    }
}
