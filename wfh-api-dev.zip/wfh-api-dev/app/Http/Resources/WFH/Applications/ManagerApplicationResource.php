<?php

namespace App\Http\Resources\WFH\Applications;

use Illuminate\Http\Resources\Json\JsonResource;

class ManagerApplicationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'validation' => $this['validation'],
            'application' => new ApplicationResource($this['application'])
        ];
    }
}
