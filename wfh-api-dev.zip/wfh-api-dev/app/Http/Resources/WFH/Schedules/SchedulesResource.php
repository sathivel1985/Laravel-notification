<?php

namespace App\Http\Resources\WFH\Schedules;

use Illuminate\Http\Resources\Json\JsonResource;

class SchedulesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(empty($this->id)) {
            return parent::toArray($request);
        }else{
            return [
                'id' => $this->id,
                'name' => $this->name,
                'name_value' => $this->name_value,
                'is_active' => $this->is_active,
                'description' => $this->description
            ];
        }


    }
}
