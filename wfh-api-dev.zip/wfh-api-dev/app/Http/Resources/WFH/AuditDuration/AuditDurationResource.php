<?php

namespace App\Http\Resources\WFH\AuditDuration;

use Illuminate\Http\Resources\Json\JsonResource;

class AuditDurationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'duration' => $this->duration,
            'description' => $this->description,
            'isActive' => $this->is_active,
        ];
    }
}
