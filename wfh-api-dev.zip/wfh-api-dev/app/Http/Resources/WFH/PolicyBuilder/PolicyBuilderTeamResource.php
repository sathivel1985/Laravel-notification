<?php

namespace App\Http\Resources\WFH\PolicyBuilder;

use Illuminate\Http\Resources\Json\JsonResource;

class PolicyBuilderTeamResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(!empty($this->id)){
            return [
                'id'            => $this->id,
                'name'          => $this->name,
                'allocations'   => TeamWeekAllocationResource::collection($this->whenLoaded('allocations'))
            ];
        }

    }
}
