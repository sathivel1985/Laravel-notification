<?php

namespace App\Http\Resources\WFH\PolicyBuilder;

use Illuminate\Http\Resources\Json\JsonResource;

class TeamWeekAllocationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'            => $this->id,
            'team'          => new PolicyBuilderTeamResource($this->whenLoaded('wfhTeam')),
            'year'          => $this->year,
            'week_number'   => $this->week_number,
            'date'          => $this->date
        ];
    }
}
