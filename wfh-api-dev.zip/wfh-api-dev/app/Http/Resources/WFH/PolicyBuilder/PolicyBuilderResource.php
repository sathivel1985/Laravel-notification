<?php

namespace App\Http\Resources\WFH\PolicyBuilder;

use Illuminate\Http\Resources\Json\JsonResource;

class PolicyBuilderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if(empty($this->id)){
            return null;
        }
        return [
            'id'            => $this->id,
            'permState'     => $this->perm_state,
            'startDate'     => $this->start_date,
            'endDate'       => $this->end_date,
            'occupancy'     => $this->occupancy,
            'execution'     => $this->execution,
            'frequency'     => $this->frequency,
            'recurringDays' => $this->recurring_days,
            'essentialList'=> $this->essential_list,
            'teams'         => PolicyBuilderTeamResource::collection($this->whenLoaded('wfhTeams')),
            'weekAllocations'=> TeamWeekAllocationResource::collection($this->whenLoaded('wfhTeamWeekAllocations')),
            'userAllocations'=> TeamUserAllocationResource::collection($this->whenLoaded('wfhTeamUserAllocations'))

        ];
    }
}
