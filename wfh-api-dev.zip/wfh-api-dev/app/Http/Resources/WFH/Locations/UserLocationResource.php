<?php

namespace App\Http\Resources\WFH\Locations;

use App\Http\Resources\UserResource;
use Illuminate\Http\Resources\Json\JsonResource;

class UserLocationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
         return [
            'id'            => $this->id,
            'name'          => $this->name,
            'address'       => $this->address,
            'distance'      => $this->distance,
            'status'        => $this->status,
            'user'          => new UserResource($this->whenLoaded('user'))
         ];
    }
}
