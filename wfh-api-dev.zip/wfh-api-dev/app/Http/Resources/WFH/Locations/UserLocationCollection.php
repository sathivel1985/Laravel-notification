<?php

namespace App\Http\Resources\WFH\Locations;

use Illuminate\Http\Resources\Json\ResourceCollection;

class UserLocationCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
