<?php

namespace App\Services;

use App\Models\ManagerUser;
use App\Models\OfficeLocation;
use App\Models\PolicyBuilder;
use App\Models\User;
use App\Models\WfhApplication;
use Exception;
use \Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Notifications\ApplicationNotifiction;
use Illuminate\Support\Facades\Notification;
class ApplicationService
{

    public $policyBuilderService;
    public $dateService;
    public $applicationService;
    public $userService;
    public function __construct(
        PolicyBuilderService $policyBuilderService,
        DateService $dateService,
        UserService $userService
    ) {
        //parent::__construct();
        $this->policyBuilderService = $policyBuilderService;
        $this->dateService  = $dateService;
        $this->userService = $userService;
    }
    public function createApplication(Request $request)
    {

        if (
            strtolower($request->state) == 'wfh'  ||
            (isset($request->over_write) && filter_var($request->over_write, FILTER_VALIDATE_BOOLEAN))
        ) {

            return $this->createWfhApplication($request);
        } else {
            return $this->createWfoApplication($request->toArray());
        }
    }
    public function createWfoApplication($request)
    {

        $requestDates = [];
        if (WfhApplication::isSpecificDay($request['type'])) {
            $requestDates = $request['specific_days'];
        }

        if (WfhApplication::isRecurring($request['type'])) {
            $requestDates = $this->dateService->getSelectedDayArray(
                $request['start_date'],
                $request['end_date'],
                $request['recurring_days']
            );
        }

        if (WfhApplication::isPermanant($request['type'])) {
            $requestDates = $this->dateService->getDatesFromRange(
                $request['start_date'],
                $request['end_date']
            );
        }
        if(isset($request['user_id']) && !empty($request['user_id'])){
            $user = User::where('id', $request['user_id'])->first();
        } else {
            $user = Auth::user();
        }
        if(empty($user->office_location_id)) {
            throw new Exception("User location is empty");
        }
        $officeLocation = OfficeLocation::where('id',$user->office_location_id)->first();
        $existingApplicationDates = $this->userApplicationApprovedDates($user,$request['state']);
        $excludedExistingApplicationDates = array_diff($requestDates, $existingApplicationDates);

        $excludedHolidays = $this->dateService->excludeHoliday($excludedExistingApplicationDates, $officeLocation);

        if(!$excludedHolidays) {
           // throw new Exception("There is no valida date to apply for this application");
            return [
                'success' => false,
                'error'   => null,
                'validateApplication' => false
            ];
        }

        $userWeekAllocationDates = $this->policyBuilderService->getTeamWeekAllocationDatesByUser($user);
        $userNotAllocatedDates = array_diff($excludedHolidays, $userWeekAllocationDates);

        $dateTeamDetails = [];
        if ($userNotAllocatedDates) {

            $policyBuilder = PolicyBuilder::where('id',$request['policy_builder_id'])->first();

            foreach ($userNotAllocatedDates as $date) {
                $dateTeamDetails[] = $this->policyBuilderService->getTeamDetailsByDate($policyBuilder, $date);
            }

            return [
                'success' => false,
                'error'   => !empty($dateTeamDetails) ? array_filter($dateTeamDetails) : null
            ];
        }

        return [
            'success'   => false,
            'error'     => null,
            'validateApplication' => false   // User Requested date and allocation date
        ];

    }
    private function createWfhApplication(Request $request)
    {
        /** Permanant type if got any differnec then we no need to  */
        return DB::transaction(function () use ($request) {
            $user = Auth::user();
            $officeLocation = OfficeLocation::where('id',$user->office_location_id)->first();
            if(empty($user->office_location_id)) {
                throw new Exception("User location is empty");
            }

            $requestArray = $request->all();
            $requestArray['user_id'] =  $request->user()->id;
            $application = WfhApplication::create($requestArray);
            $applicationDates = [];
            if( strtolower($request->state) == 'wfh') {
                $applicationDates = $this->validateApplicationDateForWfh($application,$user, $officeLocation, $requestArray);
            }
            if(strtolower($request->state) == 'wfo'){
                $applicationDates = $this->validateApplicationDateForWfo($application,$user, $officeLocation, $requestArray);
            }

            /**
             * Send Notifiction to manager
             */
            $managerUser = $this->userService->userManager($user->id);

            if(!empty($managerUser) && !empty($managerUser->manager->user->id)){
                Notification::send($managerUser->manager->user, new ApplicationNotifiction($application,'user'));
            }
            return [
                'success' => true,
                'error'   => null,
                'applicationDates' => $applicationDates
            ];
        });
    }

    public function userApplicationApprovedDates(User $user, $state = null)
    {
        $approved = array_flip(WfhApplication::STATUS)['APPROVED'];
        $applications = WfhApplication::with('dates')->where([
            'user_id' => $user->id,
            'status'  => $approved
        ])
        ->where('state',strtolower($state))
        ->get();
        $applicationDates = $applications->map(function($item){
           return $item->dates->map(function($dateIteam){
               return date('Y-m-d',strtotime($dateIteam->date));
           });
        })->flatten()->toArray();
        return array_unique($applicationDates);

    }

    public function validateApplicationDateForWfo(WfhApplication $wfhApplication, User $user, OfficeLocation $officeLocation,$request)
    {

        $existingApplicationDates = $this->userApplicationApprovedDates($user);

        if (WfhApplication::isSpecificDay($request['type']) && !isset($request['specific_days'])) {
            throw new Exception("must have specific days ");
        }

        $optionsDates = [];

        if(WfhApplication::isRecurring($request['type'])){
            $requestDates = $this->dateService->getSelectedDayArray(
                $request['start_date'],
                $request['end_date'],
                $request['recurring_days']
            );
            foreach($requestDates AS $date){
                $optionsDates[] = $date;
            }
        }

        if (WfhApplication::isSpecificDay($request['type'])) {

            foreach ($request['specific_days'] as $date) {
                $optionsDates[] = $date;
            }

        }

        if (WfhApplication::isPermanant($request['type'])) {
            $requestDates = $this->dateService->getDatesFromRange(
                $request['start_date'],
                $request['end_date']
            );
            foreach($requestDates AS $date){
                $optionsDates[] = $date;
            }
        }

        $excludedExistingApplicationDates = array_diff($optionsDates, $existingApplicationDates);
        $excludedHolidays = $this->dateService->excludeHoliday($excludedExistingApplicationDates, $officeLocation);

        if(!$excludedHolidays) {
            throw new Exception("There is no valida dates to apply for this application");
        }

        $applicationDates = [];
        $checkDatePermanant = [];
        if ( isset($request['over_write']) && filter_var($request['over_write'], FILTER_VALIDATE_BOOLEAN) ) {

            $policyBuilder = PolicyBuilder::where('id',$request['policy_builder_id'])->first();
            foreach($excludedHolidays AS $optionsDate){
                $teamStrength = $this->policyBuilderService->getTeamStrengthByDate($policyBuilder, $optionsDate);
                $isValid = $this->policyBuilderService->policyOccupancyValidation($policyBuilder, $teamStrength);
                if ($isValid) {
                    $applicationDates[] = $optionsDate;
                    $checkDatePermanant[] = $optionsDate;
                }
            }

        } else {
            $applicationDates =  $excludedHolidays;
        }

        if (  strtolower($request['state']) == 'wfo' && WfhApplication::isPermanant($request['type']) && count($checkDatePermanant) != count($excludedHolidays)) {
            throw new Exception("One of the date is not available for Permanent WFO request ");
        }

        if(!$applicationDates) {
            throw new Exception("There are no available dates.");
        }

        $insertDate = [];
        foreach($applicationDates AS $date){
            $insertDate[] = ['date' => $date];
        }

        $wfhApplication->dates()->createMany($insertDate);

        return $insertDate;

    }

    public function validateApplicationDateForWfh(WfhApplication $wfhApplication, User $user, OfficeLocation $officeLocation,$request)
    {

        if (WfhApplication::isSpecificDay($request['type']) && !isset($request['specific_days'])) {
            throw new Exception("must have specific days ");
        }

        $optionsDates = [];

        if(WfhApplication::isRecurring($request['type'])){
            $requestDates = $this->dateService->getSelectedDayArray(
                $request['start_date'],
                $request['end_date'],
                $request['recurring_days']
            );
            foreach($requestDates AS $date){
                $optionsDates[] = $date;
            }
        }

        if (WfhApplication::isSpecificDay($request['type'])) {

            foreach ($request['specific_days'] as $date) {
                $optionsDates[] = $date;
            }

        }

        if (WfhApplication::isPermanant($request['type'])) {
            $requestDates = $this->dateService->getDatesFromRange(
                $request['start_date'],
                $request['end_date']
            );
            foreach($requestDates AS $date){
                $optionsDates[] = $date;
            }
        }


        $insertDate = [];
        foreach($optionsDates AS $date){
            $insertDate[] = ['date' => $date];
        }

        $wfhApplication->dates()->createMany($insertDate);

        return $insertDate;

    }

    public function approvedApplicationListByStateAndDate($state, $date)
    {
        if (empty($state) || empty($date)) {
            return null;
        }
        $sql = "
            SELECT count(DISTINCT(APPLICATION.user_id)) AS total  FROM `wfh_application_dates` as DATES
            INNER JOIN wfh_applications as APPLICATION on APPLICATION.id= DATES.wfh_application_id
            where APPLICATION.state='".$state."'
            AND APPLICATION.status=20
            AND DATES.date='".$date."'
            AND DATES.deleted_at IS NULL
            AND APPLICATION.deleted_at IS NULL
            GROUP BY DATES.date
        ";
        $applicationData = DB::select($sql);
        if ( $applicationData ){
            $collectionObject = collect($applicationData)->first();
            return  $collectionObject->total;

        }
        return 0;
    }
}
