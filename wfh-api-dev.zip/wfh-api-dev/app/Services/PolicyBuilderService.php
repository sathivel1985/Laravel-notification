<?php

namespace App\Services;

use App\Models\OfficeLocation;
use App\Models\PolicyBuilder;
use App\Models\User;
use App\Models\WfhApplication;
use App\Models\WfhTeam;
use App\Models\WfhTeamUserAllocation;
use App\Models\WfhTeamWeekAllocation;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use DateTime;

class PolicyBuilderService {

    public $dateService;

    public function __construct(DateService $dateService)
    {
        $this->dateService = $dateService;

    }
    public function weekAllocation($weekArray = [], $teams = [])
    {
        if (!$weekArray || !$teams) {
            return;
        }
        $weekAllocations = [];
        foreach (array_chunk($weekArray,count($teams)) AS $weekNumbers)
        {
            $shiftTeams = $teams;
            foreach ($weekNumbers AS $weekNumber) {
                $teamId = array_shift( $shiftTeams );
                $exlopde = explode('-',$weekNumber);
                $weekAllocations[] = [
                    'wfh_team_id'   => $teamId,
                    'week_number'   => $exlopde[0],
                    'year'          => $exlopde[1],
                    'created_at'    => Carbon::now(),
                    'updated_at'    => Carbon::now()
                ];
            }
        }
        if ($weekAllocations) {
            WfhTeamWeekAllocation::insert($weekAllocations);
        }
        return;
    }

    public function dayAllocation($weekArray = [], $teams = [])
    {
        if (!$weekArray || !$teams) {
            return;
        }
        $weekAllocations = [];
        foreach (array_chunk($weekArray,count($teams)) AS $weekDates)
        {
            $shiftTeams = $teams;
            foreach ($weekDates AS $weekDate) {
                $teamId = array_shift( $shiftTeams );
                $weekAllocations[] = [
                    'wfh_team_id'   => $teamId,
                    'date'          => $weekDate,
                    'created_at'    => Carbon::now(),
                    'updated_at'    => Carbon::now()
                ];
            }
        }
        if ($weekAllocations) {
            WfhTeamWeekAllocation::insert($weekAllocations);
        }
        return;
    }

    public function getTeamWeekAllocationDatesByUser(User $user)
    {
        $teamUserAllocations =  $user->userWfhTeamWeekAllocation()->get();
        $dateArray = [];
        if(!$teamUserAllocations){
            return [];
        }
        if ( $teamUserAllocations ) {
            foreach ($teamUserAllocations AS $weekAllocation) {
                if (empty($weekAllocation->date) && !empty($weekAllocation->week_number)){
                    $dates = $this->dateService->getDatesByWeekNumberAndYear($weekAllocation->week_number, $weekAllocation->year);
                    $dateArray = array_merge($dateArray,$dates);
                } else {
                    $dateArray = array_merge($dateArray,[$weekAllocation->date]);
                }
            }
        }
        return $dateArray;
    }

    public function getTeamWeekAllocationDatesByPolicyBuilder(PolicyBuilder $policyBuilder)
    {
        $weekAllocations = $policyBuilder->wfhTeamWeekAllocations()->get();
        $weekAllocations = $weekAllocations->groupBy(function($item){
            return $item->wfh_team_id;
        });
        $teamDates = [];
        foreach($weekAllocations as $team_id => $teamAllocations){
            $dateArray = [];
            foreach ($teamAllocations AS $weekAllocation) {
                if (empty($weekAllocation->date) && !empty($weekAllocation->week_number)){
                    $dates = $this->dateService->getDatesByWeekNumberAndYear($weekAllocation->week_number, $weekAllocation->year);
                    $dateArray = array_merge($dateArray,$dates);
                } else {
                    $dateArray = array_merge($dateArray,[$weekAllocation->date]);
                }
            }
            $teamDates[] = [
                'wfh_team_id' => $team_id,
                'dates' => $dateArray
            ];
        }
        return $teamDates;
    }

    public function getTeamDetailsByDate(PolicyBuilder $policyBuilder, $date)
    {
        $teamList = $policyBuilder->wfhTeams()->get(['id','name']);

        $teamList = $teamList->mapWithKeys(function($item,$key){
            return [ $item->id => $item->name];
        })->toArray();

        $date = date('Y-m-d', strtotime($date));
        $existTeams = [];

        $teams= $this->getTeamWeekAllocationDatesByPolicyBuilder($policyBuilder);

        foreach ($teams AS $teamDates) {

            if (in_array($date, $teamDates['dates'])) {
                $teamStrength = $this->getTeamTotalStrength($policyBuilder, [$teamDates['wfh_team_id']]);
                $stateCounts = $this->checkApplicationDates($policyBuilder, $date);
                $strength =  ($teamStrength + $stateCounts['wfo']) - $stateCounts['wfh'];
                $isValid = $this->policyOccupancyValidation($policyBuilder,$strength);
                $percentage = $this->policyOccupancyPercentage($policyBuilder,$strength);
                $existTeams[] = [
                    'date' => $date,
                    'team' => $teamList[$teamDates['wfh_team_id']] ?? $teamDates['wfh_team_id'],
                    'occupancy' => $isValid,
                    'percentage' =>  $percentage,
                    'teamStr' => $teamStrength,
                    'stateCounts' => $stateCounts,
                    'strength' => $strength

                ];
                //unset($checkDate[$date]);
            }
            // }else{
            //     $checkDate[$date] = [
            //         'date' => $date,
            //         'team' => 'No Team at this date'
            //     ];
            // }
        }
        // if($checkDate){
        //     $existTeams = array_merge($existTeams,$checkDate);
        // }

        return $existTeams;
    }

    public function getTeamStrengthByDate(PolicyBuilder $policyBuilder, $date)
    {

        $date = date('Y-m-d', strtotime($date));
        $existTeams = [];
        $teams= $this->getTeamWeekAllocationDatesByPolicyBuilder($policyBuilder);

        foreach ($teams AS $teamDates) {
            if (in_array($date, $teamDates['dates'])) {
                $existTeams[] =   $teamDates['wfh_team_id'];
            }
        }
        $strength =  $this->getTeamTotalStrength($policyBuilder, $existTeams);
        $stateCounts = $this->checkApplicationDates($policyBuilder, $date);
        return ($strength + $stateCounts['wfo']) - $stateCounts['wfh'];
    }

    public function getTeamTotalStrength(PolicyBuilder $policyBuilder, $teams = [])
    {
        // Policybuilder essential = 1  - whole count , 0 - exclude essentail users
        $policyBuilderEssential = $policyBuilder->essential_list;
        $teamUserCount = [];
        if ($policyBuilderEssential) {
            $teamsData = WfhTeam::withCount('UserAllocations')->whereIn('id',$teams)->get();
        } else {
            $teamsData = WfhTeam::withCount('excludeEssentialUserAllocations')->whereIn('id',$teams)->get();
        }

        foreach( $teamsData AS $team){
            if ($policyBuilderEssential){
                $teamUserCount[] = $team->user_allocations_count;
            } else {
                $teamUserCount[] = $team->exclude_essential_user_allocations_count;
            }
            }

        return array_sum($teamUserCount);

    }

    public function policyOccupancyValidation(PolicyBuilder $policyBuilder, $teamStrength)
    {
        $policyBuilderCapacity = $policyBuilder->occupancy;
        $teamCapacityByDate =  $this->policyOccupancyPercentage($policyBuilder,$teamStrength);
        if( $policyBuilderCapacity > $teamCapacityByDate){
            return true;
        }
        return false;

    }
    public function policyOccupancyPercentage(PolicyBuilder $policyBuilder, $teamStrength)
    {
        $userCount = User::where('office_location_id',$policyBuilder->office_location_id)->count();
        return  $teamStrength > 0  ?  round(($teamStrength/$userCount) * 100) : 0;
    }

    public function policyBuilderApplications(PolicyBuilder $policyBuilder){
        $approved = array_flip(WfhApplication::STATUS)['APPROVED'];
        $wfoApplications = $policyBuilder->wfoApplications()->where('status',$approved)->get();
        $wfhApplications = $policyBuilder->wfhApplications()->where('status',$approved)->get();
        return [
            'wfo' => $wfoApplications,
            'wfh' => $wfhApplications
        ];
    }


    public function checkApplicationDates(PolicyBuilder $policyBuilder, $date){
        $applicationsByState = $this->policyBuilderApplications($policyBuilder);

        $wfoDates = [];
        $wfhDates = [];
        $date = date('d-m-Y', strtotime($date));
        if (isset($applicationsByState['wfo'])) {
            foreach($applicationsByState['wfo'] AS $application){
                $applicationDates = $this->applicationDates($application);
                if (!$applicationDates) {
                    continue;
                }

                if (in_array($date, $applicationDates)){
                    $wfoDates[] = $date;
                }
            }
        }
        if (isset($applicationsByState['wfh'])) {
            foreach($applicationsByState['wfh'] AS $application){
                $applicationDates = $this->applicationDates($application);
                if (!$applicationDates) {
                    continue;
                }

                if (in_array($date, $applicationDates)){
                    $wfhDates[] = $date;
                }
            }
        }

        return [
            'wfo' => count($wfoDates),
            'wfh' => count($wfhDates)
        ] ;
    }

    public function applicationDates(WfhApplication $wfhApplication)
    {
        if(strtoupper($wfhApplication->type) == 'PERMANENT'){
            $dates = $this->dateService->getDatesFromRange(
                $wfhApplication->start_date,
                $wfhApplication->end_date
            );
        }else{
            $dates = $wfhApplication->dates()->pluck('date')->all();
        }
        return $dates;
    }

    public function holidayDates(OfficeLocation $officeLocation)
    {
        $holidays = $officeLocation->holidays()->get();
        $dateArray = [];
        foreach($holidays AS $holiday){
            $dates = $this->dateService->getDatesFromRange(
                $holiday->start_date,
                $holiday->end_date
            );
            $dateArray = array_merge($dateArray,$dates);
        }

        return $dateArray;

    }

    public function userAllocationByPolicyBuilder(PolicyBuilder $policyBuilder, $date)
    {
        // return $policyBuilder->wfhTeamUserAllocations()->get();
        $teams= $this->getTeamWeekAllocationDatesByPolicyBuilder($policyBuilder);
        $teamIds = [];
        foreach ($teams AS $teamDates) {

            if (in_array($date, $teamDates['dates'])) {
                array_push($teamIds,$teamDates['wfh_team_id']);
            }
        }

        return WfhTeamUserAllocation::whereIn('wfh_team_id',$teamIds)->get();
    }

    public function createUserAllocationByTeam($teams, $officeLocationId)
    {
        if(empty($officeLocationId) OR empty($teams)) {
            return ;
        }
        $users = User::where('office_location_id',$officeLocationId)
                        ->where('status',10)
                        ->get();
        $team = WfhTeam::whereIn('id', $teams)->first();
        if($users) {

            $usersArray = [];
            foreach($users As $user){
                $usersArray[] = new WfhTeamUserAllocation([
                    'user_id' => $user->id
                ]);
            }

            $team->userAllocations()->saveMany($usersArray);
            return;
        }


    }

}
