<?php

namespace App\Services;

use App\Http\Controllers\ApiController;
use App\Http\Resources\Api\Admin\User\UserLogResource;
use App\Models\ManagerUser;
use App\Models\Permission;
use App\Models\User;
use App\Models\UserLog;
use App\Notifications\EmployeeAprroval;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
class UserService
{
    public function getHumanResources() {
        $users = User::where('id',11)->get();
        return $users;
    }

    public function getUsersByPermission($permission, $officeLocationId = null)
    {
        if (empty($permission)) {
            return null;
        }

        if (is_array($permission)) {

           $permissionCollection = Permission::with('roles.users')->whereIn('name', $permission)
            ->get();

        }else{
            $permissionCollection = Permission::with('roles.users')->where('name', $permission)
            ->get();

        }
        $permissionCollection =  $permissionCollection->pluck('roles')
                ->collapse()
                ->pluck('users')
                ->collapse()
                ->unique();
        if (!empty($officeLocationId)){
            $permissionCollection = $permissionCollection->where('office_location_id',$officeLocationId);
        }
        Log::info(print_r($permissionCollection->toArray(), true));
        return $permissionCollection;



    }

    public function createNewUser(Request $request, $requestorId, $isAdmin = false)
    {
        $user = User::create($request->all());

        if ($request->has('roles') && count($request->roles)>0) {
                $roles = array_filter($request->roles);
                $user->roles()->sync($roles);
        }

        if( $isAdmin ) {
            $user->status = "active";
            $user->save();
        }

        $userLog = [
            'requestor_id' => $requestorId,
            'user_id'      => $user->id,
            'type'         => 'joining',
            'type_date'    => $request->joining_date ?? null,
            'status'       => ($isAdmin) ? 'approved':null,
            'status_date'  => ($isAdmin) ? Carbon::today() : null,
            'approver_id'  => ($isAdmin) ? $requestorId : null,
        ];
        $userLog = UserLog::create($userLog);

        return [
            'user' => $user,
            'userLog' => $userLog
        ];
    }

    public function userLeavingRequest(Request $request)
    {
        $userLog = UserLog::create([
            'requestor_id' =>  $request->user()->id,
            'user_id'      => $request->user_id,
            'type'         => 'leaving',
            'type_date'    => $request->leaving_date
        ]);
        return  $userLog->load(['user','requestor']);
    }

    public function userRequestProcess(Request $request, UserLog $user_log)
    {
        try{
            return DB::transaction(function () use ($user_log, $request) {
                if($request->status == 'rejected'){
                    $user_log->status = 'rejected';
                }
                if($request->status == 'approved'){
                    $user_log->status = 'approved';
                    $user = User::findOrFail($user_log->user_id);
                    if ($user_log->type == 'joining') {
                        $user->joining_date = $user_log->type_date;
                        $user->status = 'active';
                    }
                    if ($user_log->type == 'leaving') {
                        $user->leaving_date = $user_log->type_date;
                        $user->status = 'inactive';
                    }
                    $user_log->status_date = Carbon::today();
                    $user->save();
                }

                $user_log->approver_id = $request->user()->id;
                $user_log->save();
                Notification::send($user_log->requestor()->get(), new EmployeeAprroval($user_log));
                $user_log = $user_log->load(['user','requestor','approver']);
                return new UserLogResource($user_log);
            });

        }catch(Exception $exception){
            return "Something Wrong, Please try again ".$exception->getMessage();
        }

    }

    public function userManager($userId)
    {
        if(empty($userId)){
            return null;
        }
        return ManagerUser::with('manager.user')->where('user_id', $userId)->first();
    }

    public function totalUserByLocation($locationId)
    {
         /** 10 is active 20 is in-active */
        return DB::table('users')
                ->where([
                    'status'=>10,
                    'office_location_id' => $locationId
                ])
                ->whereNull('deleted_at')
                ->count();
    }
    public function getUserPermissions($user)
    {
        return Permission::whereHas('roles.users',function($query) use ($user){
            $query->where('users.id',$user);
        })->get();
    }

    public function userResponse($user, $userId) {
        return response()->json(['data'=>[
                'roles'=>$user->roles()->get()->map(function ($item) {
                        return [
                            'id'        => $item->id,
                            'name'      => $item->name
                        ];
                }),
                'permissions'=>$this->getUserPermissions($userId)->map(function ($item) {
                    return [
                        'id'        => $item->id,
                        'name'      => $item->name
                    ];
                }),
                'user'=>$user
            ]
        ]);
    }
}
