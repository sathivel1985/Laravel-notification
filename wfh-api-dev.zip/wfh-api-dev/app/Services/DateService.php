<?php

namespace App\Services;

use App\Models\OfficeLocation;
use App\Models\WfhTeamWeekAllocation;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use DateTime;

class DateService {

    public function getStartAndEndDate($week, $year)
    {
        $dto = new DateTime();
        $dto->setISODate($year, $week);
        $ret['week_start'] = $dto->format('Y-m-d');
        $dto->modify('+6 days');
        $ret['week_end'] = $dto->format('Y-m-d');
        return $ret;
    }

    // Public function getRangeDates( $start, $end)
    // {
    //     $dayArray = [];
    //     $period = CarbonPeriod::create($start, $end);
    //     // Iterate over the period
    //     foreach ($period as $date) {
    //         $dayArray[] = $date->format('Y-m-d');
    //     }
    //    return $dayArray;
    // }

    public function getDatesByWeekNumberAndYear($week, $year)
    {
        $weekStartAndEndDate = $this->getStartAndEndDate($week, $year);

        $dates = $this->getDatesFromRange($weekStartAndEndDate['week_start'],$weekStartAndEndDate['week_end']);
        return $dates;
    }

    Public function getWeekNumberArray($start,$end)
    {
       $startTime = strtotime($start);
       $endTime = strtotime($end);
       $weeks = array();
       while ($startTime < $endTime) {
           $weeks[] = date('W', $startTime).'-'. date('Y', $startTime);
           $startTime += strtotime('+1 week', 0);
       }

       return $weeks;
    }

    Public function getSelectedDayArray( $start, $end, $days = [])
    {
        $dayArray = [];
        $period = CarbonPeriod::create($start, $end);
        // Iterate over the period
        foreach ($period as $date) {
            if (in_array($date->format('N'),$days) ) {
                $dayArray[] = $date->format('Y-m-d');
            }
        }
       return $dayArray;
    }

    public function getDatesFromRange($start, $end)
    {
        $dayArray = [];
        $period = CarbonPeriod::create($start, $end);
        // Iterate over the period
        foreach ($period as $date) {
            $dayArray[] = $date->format('Y-m-d');
        }
       return $dayArray;
    }

    public function excludeHoliday($weekArray, OfficeLocation $officeLocation)
    {
        $holidays = $officeLocation->holidays()->get();
        $dateArray = [];
        foreach($holidays AS $holiday){
            $dates = $this->getDatesFromRange(
                $holiday->start_date,
                $holiday->end_date
            );
            $dateArray = array_merge($dateArray,$dates);
        }
        return array_diff($weekArray, $dateArray);
    }
}
